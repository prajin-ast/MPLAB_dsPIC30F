/* File:    EX00_00.C
   Purpose: Test...
*/

#include <p30fxxxx.h>     // generic header file for dsPIC
#include <stdio.h>        // include I/O facilities
#include <timer.h>

_FOSC(CSW_FSCM_OFF & XT); // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);           // Watchdog timer off

void delay(unsigned int i)
{
  unsigned int j;
  while(i--) {
    for(j=0;j<1000;j++)
      Nop();      
  }  
}  

void xConfigIntTimer1(unsigned int config)
{
    _T1IF = 0;                   /* clear IF bit */
    _T1IP = (config &0x0007);    /* assigning Interrupt Priority */
    _T1IE = (config &0x0008)>>3; /* Interrupt Enable /Disable */
}


int main(void)
{
  _TRISD0 = 0;      // Set RD0 output
  
  xConfigIntTimer1( T1_INT_ON & T1_INT_PRIOR_3);
  
  while (1) {       // Loop nothing
    _LATD0 = !_LATD0;
    delay(250);    
  }          
  
	return 0;
} 

