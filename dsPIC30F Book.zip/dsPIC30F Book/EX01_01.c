/* File:    EX01_01.C
   Purpose: Hello MPLAB C
*/

#include <p30fxxxx.h>     // generic header file for dsPIC
#include <stdio.h>        // Standard I/O

_FOSC(CSW_FSCM_OFF & XT); // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);           // Watchdog timer off

int main(void)
{
  printf("Hello MPLAB C!\n");
    
  while (1) {             // Loop nothing
  }          
  
	return 0;
} 
