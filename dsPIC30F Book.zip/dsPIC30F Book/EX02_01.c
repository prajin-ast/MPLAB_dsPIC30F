/* File:    EX02_01.C
   Purpose: Structure of a MPLAB C Program 
*/

#include <p30fxxxx.h>     // generic header file for dsPIC
#include <stdio.h>        // Standard I/O

_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);             // Watchdog timer off

int main(void)   // Function Heading
{                
  int i;        // variables declaration
  
  i = 10;       // statements 
  
  printf("MPALB C Programming\n");
  printf("i is %d\n",i);
    
  while (1) {   // Loop nothing
  }  
  
  return 0;     // Return type
}
