/* File:    EX02_02.C
   Purpose: Program to calculate the area of a triagle
*/

#include <p30fxxxx.h>     // generic header file for dsPIC

_FOSC(CSW_FSCM_OFF & XT); // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);           // Watchdog timer off

int main(void)
{
  float area, base, height;

  base = 10.0;
  height = 5.5;

  area = (base * height) / 2.0;
    
  return 0; 
}
