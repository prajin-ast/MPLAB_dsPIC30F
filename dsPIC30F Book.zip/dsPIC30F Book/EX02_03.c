/* File:    EX02_03.C
   Purpose: Program to calculate the area of a triagle
*/

#include <p30fxxxx.h>       // generic header file for dsPIC

_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);             // Watchdog timer off

// triagle function 
float calc_triangle(float base, float height)
{
  float a=0;      // local variables declarations
    
  a = (base * height) / 2.0;   // statement
  
  return a;     // return area
}  

// main function
int main(void)
{
   float area;          // variables declarations

   area = 0;            // clear data
   
   area = calc_triangle(10.0, 5.5);  // call function 

   return 0; 
}
