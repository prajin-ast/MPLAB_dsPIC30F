/* File:    EX02_04.C
   Purpose: TRISD/PORTD Register
*/

#include <p30fxxxx.h>       // generic header file for dsPIC

_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled, XT w/PLL
_FWDT(WDT_OFF);             // Watchdog timer off

int main(void)
{
  TRISD = 0;        // Clear TRISD register for output  
  PORTD = 0;        // Clear PORTD register   
  
  while (1) {       // Loop forever
    PORTD = 0x01;   // Set PORTD = 1
    PORTD = 0;      // Clear PORTD = 0
    PORTD = 0x02;   // Set PORTD = 2
    PORTD = 0;      // Clear PORTD = 0
    PORTD = 0x03;   // Set PORTD = 3
  }          
  
	return 0;
} 
