/*
 * File      : EX03_01.c
 * Purpose   : I/O Port (Switch + LED)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 06/06/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// LED & Switch
// LED 0  : RE0
// LED 1  : RE1
// LED 2  : RE2
// SW  1  : RB0
// SW  2  : RB1
// SW  3  : RB2

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off

            
//----------------------------------------------------:Defines
#define TRUE              1

// LED
#define TRIS_LED    TRISE
#define LED_1       _LATE0
#define LED_2       _LATE1
#define LED_3       _LATE2

// Switch
#define TRIS_SW     TRISB
#define SW_1        _RB0
#define SW_2        _RB1
#define SW_3        _RB2


//----------------------------------------------------:Main
int main(void)
{
  // Set PORT LED & SW
  ADPCFG = 0xFF;          // ADC Input Off (PORTB)
  TRIS_SW = 0xFF;         // PORTB Input
  TRIS_LED = 0;           // PORTE Output
      
  while (TRUE) {
    if (SW_1 == 0) {
      LED_1 = 1;          // On
      LED_2 = 0;          // Off
      LED_3 = 0;          // Off
    }

    if (SW_2 == 0) {
      LED_1 = 0;
      LED_2 = 1;
      LED_3 = 0;
    }

    if (SW_3 == 0) {
      LED_1 = 0;
      LED_2 = 0;
      LED_3 = 1;
    }    
  }
  
  return 0;
}
