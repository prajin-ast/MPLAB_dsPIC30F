/*
 * File      : EX04_02.c
 * Purpose   : I/O Port (7 Segments Display & KeyPad)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 06/06/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// 7 Segments Display & KeyPad (MCT-02-2)
// PORTE Configure the LED 7 Segments as follows:
// LED seg a    Pin RE0
// LED seg b    Pin RE1
// LED seg c    Pin RE2
// LED seg d    Pin RE3
// LED seg e    Pin RE4
// LED seg f    Pin RE5
// LED seg g    Pin RE8
// LED seg dp   Pin xx (not use)
// LED Dig1     Pin RB0
// LED Dig2     Pin RB1
// LED Dig3     Pin RB2
// LED Dig4     Pin RB3

// PORTB/PORTC Connect to key switch matrix (Row x Col)
// Row
// R1 -> RB0  	, R2 -> RB1
// R3 -> RB2  	, R4 -> RB3
// Column
// C1 -> RD0	  , C2 -> RD1
// C3 -> RF2

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off


//----------------------------------------------------:Data types
typedef unsigned int      UINT16_T;
typedef unsigned char     UINT8_T;

            
//----------------------------------------------------:Defines
#define TRUE              1
#define KBD_WAIT          Delay_MS(2)

// LED 7 Segments 
#define TRIS_SEG          TRISE     // LED Segments
#define LAT_SEG           LATE
#define TRIS_DIG          TRISB     // Digit Segments
#define LAT_DIG           LATB
// Key pad
#define KEY_TRIS_OUT_C1   _TRISD0   // LATC scan key pad
#define KEY_TRIS_OUT_C2   _TRISD1
#define KEY_TRIS_OUT_C3   _TRISF2
#define KEY_OUT_C1        _LATD0
#define KEY_OUT_C2        _LATD1
#define KEY_OUT_C3        _LATF2
#define KEY_TRIS_IN       TRISB     // PORTB read key pad
#define KEY_IN            PORTB


// LED MAP for 7 Segments
UINT16_T LED_MAP[17] = {0x003F, 0x0006, 0x005B, 0x004F, 0x0066, //0,1,2,3,4
                        0x006D, 0x007D, 0x0007, 0x007F, 0x006F, //5,6,7,8,9
                        0x0077, 0x007C, 0x0039, 0x005E, 0x0079, //A,b,C,d,E
	     	                0x0071, 0x0080};	   		 			           //F,.
	     	                 
UINT8_T kbd_pad[4][3] ={{'7','8','9'},
  			                {'4','5','6'},
	  		                {'1','2','3'},
				                {'*','0','#'},
                        };
                        
UINT8_T buf_num[4]={0,1,2,3};    // Buffer number


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 1x)
void Delay_MS(UINT16_T ms)
{
  UINT16_T i;

  for (; ms>0; ms--)
    for (i=0; i<182; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:KBD Get
unsigned char KBD_Get(void)
{
  static char last_key;
  UINT8_T col, row;

  KEY_TRIS_IN = 0x0F;   // Set port for scankey
      
  for (col=0; col<3; col++) {    
    if (col == 0) { KEY_OUT_C1 = 0; KEY_OUT_C2 = KEY_OUT_C3 = 1; }
    if (col == 1) { KEY_OUT_C2 = 0; KEY_OUT_C1 = KEY_OUT_C3 = 1; }
    if (col == 2) { KEY_OUT_C3 = 0; KEY_OUT_C1 = KEY_OUT_C2 = 1; }
    
    row = (KEY_IN & 0x0F);      // read row                
    
    switch (row) {
      case 0x0E: row = 3; break;
      case 0x0D: row = 2; break;
      case 0x0B: row = 1; break;
      case 0x07: row = 0; break;
      default:   row = 4;
    }
        
    if (row != 4) {
      if (kbd_pad[row][col] == last_key)  
        return ('\0');
        
      last_key = kbd_pad[row][col];
      return (last_key);
    }
    KBD_WAIT;       // delay kbd
  }
  
  last_key = '\0';
  return (last_key);
  
}

//----------------------------------------------------:Display Segs
void Display_Segs(void)
{  
  UINT16_T LED_BIT7; 
  
  TRIS_SEG = 0;      // set output Segments
  TRIS_DIG = 0;      // set output digit PORTB
  
  LED_BIT7 = 0x0100 & (LED_MAP[buf_num[0]]<<2);
  LAT_SEG = ~(LED_MAP[buf_num[0]] | LED_BIT7);
  LAT_DIG = 0x0E;   //1110 (digit1)
  Delay_MS(1);
  
  LED_BIT7 = 0x0100 & (LED_MAP[buf_num[1]]<<2);
  LAT_SEG = ~(LED_MAP[buf_num[1]] | LED_BIT7);
  LAT_DIG = 0x0D;   //1101 (digit2)
  Delay_MS(1);
  
  LED_BIT7 = 0x0100 & (LED_MAP[buf_num[2]]<<2);
  LAT_SEG = ~(LED_MAP[buf_num[2]] | LED_BIT7);
  LAT_DIG = 0x0B;   //1011 (digit3)
  Delay_MS(1);
  
  LED_BIT7 = 0x0100 & (LED_MAP[buf_num[3]]<<2);
  LAT_SEG = ~(LED_MAP[buf_num[3]] | LED_BIT7);
  LAT_DIG = 0x07;   //0111 (digit4)
  Delay_MS(1);
}

//----------------------------------------------------:Main
int main(void)
{
  UINT8_T ch ='\0';

  // Set port for scankey
  ADPCFG = 0xFF;          // ADC Input Off (PORTB)
  KEY_TRIS_OUT_C1 = 0;    // Colum output
  KEY_TRIS_OUT_C2 = 0;
  KEY_TRIS_OUT_C3 = 0;
    
  while (TRUE) {
        
    ch = KBD_Get();       // Scankey
        
    if (ch !='\0') {
      buf_num[0] = buf_num[1];
      buf_num[1] = buf_num[2];
      buf_num[2] = buf_num[3];
      if (ch == '*') {
        buf_num[3] = 10;      // for display 'A'
      } else {
        if (ch == '#') {
          buf_num[3] = 11;    // for display 'b'
        } else {
          buf_num[3] = ch - '0';  // for display '0'-'9'
        }  
      }
    }
    
    Display_Segs();
    
  }
  
  return 0;
}
