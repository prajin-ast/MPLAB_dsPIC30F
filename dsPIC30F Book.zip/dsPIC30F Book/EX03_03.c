/*
 * File      : EX04_03.c
 * Purpose   : I/O Port (LCD 16x2 & KeyPad)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 06/06/08
 * Ref.      : - 
*/

//----------------------------------------------------:NOTE
// LCD PIN
// GND -> LCD R/W
// RE0 -> LCD D4
// RE1 -> LCD D5
// RE2 -> LCD D6
// RE3 -> LCD D7
// RE4 -> LCD RS
// RE5 -> LCD E 
// Key switch matrix (Row x Col)
// Row
// R1 -> RB0  	, R2 -> RB1
// R3 -> RB2  	, R4 -> RB3
// Column
// C1 -> RD0	  , C2 -> RD1
// C3 -> RF2

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <string.h>         // for strcpy, strcat function
#include <stdlib.h>         // for atol function


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off


//----------------------------------------------------:Library
#include "LIB_LCD16x2.C"    // LCD Module Library 
#include "LIB_Scankey.C"    // Scankey Module Library

           
//----------------------------------------------------:Defines
#define TRUE              1

// LED
#define LED_TRIS          _TRISF3
#define LED_FLASH         _LATF3


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 1x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<182; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Main
int main(void)
{
  char x = 1;
  char buf_str[17];
  char buf_chr[1];
  long dly = 0;
  
  // Set port for scankey
  ADPCFG = 0xFF;          // ADC Input Off (PORTB)
  KEY_TRIS_OUT_C1 = 0;    // Colum output
  KEY_TRIS_OUT_C2 = 0;
  KEY_TRIS_OUT_C3 = 0;

  LED_TRIS = 0;           // Set output
  
  LCDInit();              // Initialize the LCD display
  LCDClrscr();            // Clear screen
  LCDPrintxy(1,1,0, "Your Input Char..");
  
  strcpy(buf_str,"0");    // Initialize buffer fist time
  
  while (TRUE) {
        
    buf_chr[0] = KBDGet();     // Scan keypad
        
    if (buf_chr[0] !='\0') {
      if (buf_chr[0] == '*') {
        // Clear screen, Put String & Set to first position
        LCDClrscr();
        LCDPrintxy(1,1,0, "Your Input Char..");   
        x = 1;
        strcpy(buf_str,"0");    // Clear buf_str
      } else if (buf_chr[0] == '#') {       
          LCDPrintxy(1,1,0, "LED ON..Time(ms)");
          dly = atol(buf_str);  // Convert string to long
          LED_FLASH = 1; 
          Delay_MS(dly);
          LED_FLASH = 0;
          LCDClrscr();
          LCDPrintxy(1,1,0, "Your Input Char..");   
          x = 1;                // Set to first position          
          strcpy(buf_str,"0");  // Clear buf_str
        } else {
            LCDGotoxy(x++,2);
            LCDPutchar(buf_chr[0]);
            // Appends a copy of the source string to 
            // the end of the destination string. 
            strcat(buf_str,buf_chr);    
            if (x > 16) x = 1;
        }
    }
  }
  
  return 0;
}
