/*
 * File      : EX04_03x.c
 * Purpose   : I/O Port (LCD 16x2 & KeyPad)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 06/06/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// LCD PIN
// GND -> LCD R/W
// RE0 -> LCD D4
// RE1 -> LCD D5
// RE2 -> LCD D6
// RE3 -> LCD D7
// RE4 -> LCD RS
// RE5 -> LCD E 
// Key switch matrix (Row x Col)
// Row
// R1 -> RB0  	, R2 -> RB1
// R3 -> RB2  	, R4 -> RB3
// Column
// C1 -> RD0	  , C2 -> RD1
// C3 -> RF2

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <string.h>         // for strcat() function
#include <stdlib.h>         // for atol() function


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off


//----------------------------------------------------:Data types
typedef unsigned int      UINT16_T;
typedef unsigned char     UINT8_T;

//----------------------------------------------------:Module
#include "LIB_LCD16x2.C"    // LCD Module Library 

            
//----------------------------------------------------:Defines
#define TRUE              1
#define KBD_WAIT          Delay_MS(2)

// Key pad
#define KEY_TRIS_OUT_C1   _TRISD0   // LATC scan key pad
#define KEY_TRIS_OUT_C2   _TRISD1
#define KEY_TRIS_OUT_C3   _TRISF2
#define KEY_OUT_C1        _LATD0
#define KEY_OUT_C2        _LATD1
#define KEY_OUT_C3        _LATF2
#define KEY_TRIS_IN       TRISB     // PORTB read key pad
#define KEY_IN            PORTB

// LED
#define LED_TRIS          _TRISF3
#define LED_FLASH         _LATF3
	     	                 
UINT8_T kbd_pad[4][3] ={{'7','8','9'},
  			                {'4','5','6'},
	  		                {'1','2','3'},
				                {'*','0','#'},
                        };
                        

//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 1x)
void Delay_MS(unsigned int ms)
{
  UINT16_T i;

  for (; ms>0; ms--)
    for (i=0; i<182; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Get KBD
unsigned char Get_KBD(void)
{
  static char last_key;
  UINT8_T col, row;

  KEY_TRIS_IN = 0x0F;   // Set port for scankey
      
  for (col=0; col<3; col++) {    
    if (col == 0) { KEY_OUT_C1 = 0; KEY_OUT_C2 = KEY_OUT_C3 = 1; }
    if (col == 1) { KEY_OUT_C2 = 0; KEY_OUT_C1 = KEY_OUT_C3 = 1; }
    if (col == 2) { KEY_OUT_C3 = 0; KEY_OUT_C1 = KEY_OUT_C2 = 1; }
    
    row = (KEY_IN & 0x0F);      // read row                
    
    switch (row) {
      case 0x0E: row = 3; break;
      case 0x0D: row = 2; break;
      case 0x0B: row = 1; break;
      case 0x07: row = 0; break;
      default:   row = 4;
    }
        
    if (row != 4) {
      if (kbd_pad[row][col] == last_key)  
        return ('\0');
        
      last_key = kbd_pad[row][col];
      return (last_key);
    }
    KBD_WAIT;       // delay kbd
  }
  
  last_key = '\0';
  return (last_key);
  
}

//----------------------------------------------------:Main
int main(void)
{
  UINT8_T x = 1;
  char buf_str[17];
  char buf_chr[] = "0";
  long dly = 0;
  
  // Set port for scankey
  ADPCFG = 0xFF;          // ADC Input Off (PORTB)
  KEY_TRIS_OUT_C1 = 0;    // Colum output
  KEY_TRIS_OUT_C2 = 0;
  KEY_TRIS_OUT_C3 = 0;

  LED_TRIS = 0;           // Set 
  
  // Initialize the LCD display
  LCDInit();  
  LCDClrscr();
  LCDPrintxy(1,1,0, "Your Input Char..");
  // Initialize buffer fist time
  strcpy(buf_str,"0");
  
  while (TRUE) {
        
    buf_chr[0] = Get_KBD();     // Scan keypad
        
    if (buf_chr[0] !='\0') {
      if (buf_chr[0] == '*') {
        // Clear screen & Put String
        LCDClrscr();
        LCDPrintxy(1,1,0, "Your Input Char..");   
        x = 1;                  // Set to first position
        strcpy(buf_str,"0");    // Clear buf_str
      } else if (buf_chr[0] == '#') {
          dly = atol(buf_str);
          LED_FLASH = 1; 
          Delay_MS(dly);
          LED_FLASH = 0;
          LCDClrscr();
          LCDPrintxy(1,1,0, "Your Input Char..");   
          x = 1;                  // Set to first position
          strcpy(buf_str,"0");    // Clear buf_str
        } else {
            LCDGotoxy(x++,2);
            LCDPutchar(buf_chr[0]);
            strcat(buf_str,buf_chr);
            if (x > 16) x = 1;
        }
    }
  }
  
  return 0;
}
