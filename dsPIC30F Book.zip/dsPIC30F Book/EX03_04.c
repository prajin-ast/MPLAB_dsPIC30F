/*
 * File      : EX04_04.c
 * Purpose   : I/O Port (TGLCD 128x64 & KeySwitch)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 06/06/08
 * Ref.      : - 
*/

//----------------------------------------------------:NOTE
// GLCD PIN
// 1      : VSS     to GND
// 2      : VDD     to +5V
// 3      : V0      to VR  (Constrast adjustment)
// 4      : RS      to RB0
// 5      : R/W     to RB1
// 6      : E       to RB2
// 7-12   : DB0-DB5 to RE0-RE5
// 13-14  : DB6-DB7 to RD0-RD1
// 15     : CS1     to RB3
// 16     : CS2     to RB4
// 17     : RST     to RB5
// 18     : VEE     to 20k Ohm POT
// 19     : A       to +5V (Positive voltage for LED backlight)
// 20     : K       to GND (Negavtive voltage for LED backlight)

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC


//----------------------------------------------------:Config fuses
//_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FOSC(CSW_FSCM_OFF & XT_PLL16); // Sw Disabled, Mon Disabled , XT w/PLL 16x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Library
#define GLCD_DATA_MAKE8_BIT // Use 2 Port for 8 bit
#include "jFont8x16.dat"    // JIN Font (Ref..Thai Font 8x16 (VTHAI.FONT))
#include "LIB_GLCD.C"       // GLCD 128x64 Module Library 
#include "LIB_GGLCD.C"      // Graphics Library
#include "LIB_TGLCD.C"      // Thai GLCD Library


//----------------------------------------------------:Defines
#define TRUE              1


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 16x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<816; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Draw Status LED
void Draw_Status_LED(char led, char status)
{
  if (led == 1) {
    GGLCDRect(45, 44, 75, 64, 1, 0);  // Draw a filled white rectangle
    GGLCDCircle(55, 35, 7, 1, 0);     // Draw a filled white Circle
    if (status) {
      TGLCDThaixy(50, 42, "ON");
    } else {
      TGLCDThaixy(45, 42, "OFF");
    }
    GGLCDCircle(55, 35, 7, status, 1);// Draw Circle
  }
  
  if (led == 2) {
    GGLCDRect(80, 44, 105, 64, 1, 0); // Draw a filled white rectangle
    GGLCDCircle(90, 35, 7, 1, 0);     // Draw a filled white Circle
    if (status) {
      TGLCDThaixy(85, 42, "ON");
    } else {
      TGLCDThaixy(80, 42, "OFF");
    }   
    GGLCDCircle(90, 35, 7, status, 1);// Draw Circle
  }
}

//----------------------------------------------------:Main
int main(void)
{   
  GLCDInit(ON);           // Init GLCD 128x64
  GLCDFillScreen(0);      // Clear Screen
  
  _TRISF2 = 0;            // Set output
  _TRISF3 = 0;
  _TRISC13 = 1;           // Set input
  _TRISC14 = 1;
  
  _LATF2 = 0;             // Clear port
  _LATF3 = 0;

  TGLCDThaixy(20,0, "ʶҹС�÷ӧҹ");
  TGLCDThaixy(10,12, "LED:  1    2");
  GGLCDCircle(55, 35, 7, 0, 1);   // LED 1
  GGLCDCircle(90, 35, 7, 0, 1);   // LED 2
  TGLCDThaixy(45, 42, "OFF");
  TGLCDThaixy(80, 42, "OFF");
  
  while (TRUE) {
    if (_RC13 == 0) {
      _LATF2 = !_LATF2;   // Toggle port
      Draw_Status_LED(1, _LATF2);
    }
    if (_RC14 == 0) {
      _LATF3 = !_LATF3;   // Toggle port
      Draw_Status_LED(2, _LATF3);
    }
    Delay_MS(1000);
  }
  
  return 0;
}
