/*
 * File      : LAB04_01.c
 * Purpose   : INTx (External Interrupt)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 01/07/08
 * Ref.      : - 
*/

//----------------------------------------------------:NOTE
// External Interrupt PIN (dsPIC30F2010)
// RE8 -> INT0
// RD0 -> INT1

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <ports.h>          // IO ports module library functions


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off

           
//----------------------------------------------------:Defines
#define TRUE              1

typedef unsigned char byte;


//----------------------------------------------------:INT0 Interrupt
void _ISR _INT0Interrupt(void)
{
  LATB = 0x0F;    // Set RB0-RB3
  Delay_MS(200);
  _INT0IF = 0;    // Clear INT0 Interrupt flag
}

//----------------------------------------------------:INT1 Interrupt
void _ISR _INT1Interrupt(void)
{
  LATB = 0xF0;     // Set RB4,RB5
  _LATE0 = 1;     // Set RE0
  _LATE1 = 1;     // Set RE1
  Delay_MS(200);
  _INT1IF = 0;    // Clear INT1 Interrupt flag
}

//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 1x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<182; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Rotate left
byte Rotate_Left(byte *x, byte i)
{
  for (; i>0; i--)
    *x = (*x<<1)|(*x>>7);
    
  return (*x);
}

//----------------------------------------------------:Main
int main(void)
{ 
  unsigned int config;
  byte rl = 1, dout = 1;

  ADPCFG = 0xFF;    // ADC Input Off (PORTB)
  TRISB = 0;        // Set PORTB output
  _TRISE0 = 0;      // Set RE0 output
  _TRISE1 = 0;      // Set RE1 output

  LATB = 0;         // Clear PORTB
  _LATE0 = 0;       // Clear RE0
  _LATE1 = 0;       // Clear RE1

  // External Interrupt (INT0,INT1)
  config = FALLING_EDGE_INT;
  ConfigINT0(EXT_INT_ENABLE & config);  // INT0
  config = RISING_EDGE_INT;
  ConfigINT1(EXT_INT_ENABLE & config);  // INT1

  while (TRUE) {          
    if (dout < 0x40) {
      LATE = 0;         // Clear PORTE
      LATB = dout;      // Output PORTB   
    } else {
      LATB = 0;         // Clear PORTB
      LATE = dout>>6;   // Output RE0 or RE1
    }                  
    dout = Rotate_Left(&rl,1);
    Delay_MS(500);
  }
  
  return 0;
}
