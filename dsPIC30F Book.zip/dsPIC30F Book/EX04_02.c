/*
 * File      : EX04_02.c
 * Purpose   : CN interrupts
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 01/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// CN PIN (dsPIC30F2010)
// RC14 -> CN0
// RC13 -> CN1
// RB0  -> CN2
// RB1  -> CN3

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <ports.h>          // IO ports module library


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);   // Sw Disabled, Mon Disabled , XT w/PLL 1x
_FWDT(WDT_OFF);             // Watchdog timer off

            
//----------------------------------------------------:Defines
#define TRUE              1

#define LED_TRIS          TRISE
#define LED_MOVE          LATE

//----------------------------------------------------:Data types
typedef unsigned int      UINT16_T;
typedef unsigned char     UINT8_T;


UINT16_T  dly = 50;

//----------------------------------------------------:CN Interrupt
// Change Notification Interrupt function
void _ISR _CNInterrupt(void)
{
  if (_RC14 == 0) dly = 100;
  if (_RC13 == 0) dly = 200;
  if (_RB0 == 0) dly = 500; 
  if (_RB1 == 0) dly = 1000;
  if (_RB1 == 0 && _RC14 == 0) dly = 50;
  
  _CNIF = 0;  // Clear CN Interrupt flag
}
                        
//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 1x)
void Delay_MS(unsigned int ms)
{
  UINT16_T i;

  for (; ms>0; ms--)
    for (i=0; i<182; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Main
int main(void)
{
  UINT8_T led_m = 1;
    
  ADPCFG = 0xFF;          // ADC Input Off (PORTB)
  LED_TRIS = 0;           // Set PORTE output    
  
  // Enable CN interrupt and set priority
  ConfigIntCN( CHANGE_INT_ON &      // Interrupts On
               CHANGE_INT_PRI_3 &   // Setting the priority
               0xFF00000F           // Enable CN0-CN3 only
              );
                
  while (TRUE) {
    
    LED_MOVE = led_m;
    led_m = led_m << 1;
    if (led_m == 0x20) led_m = 1;
    Delay_MS(dly);
    
  }
  
  return 0;
}
