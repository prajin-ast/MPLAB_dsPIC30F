/*
 * File      : EX05_01.c
 * Purpose   : Timer1 (Timer mode)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 04/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <timer.h>          // Timer module library functions 


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled , XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off

            
//----------------------------------------------------:Defines
#define TRUE              1


//----------------------------------------------------:Data types
typedef unsigned char byte;


//----------------------------------------------------:Global Variable
byte tick=0;


//----------------------------------------------------:Function prototype
void Delay_MS(unsigned int ms);


//----------------------------------------------------:Timer1 Interrupt
void _ISR _T1Interrupt(void)
{
  char i;
  
  if (++tick == 2) {
    _LATE2 = 1;
    _LATE3 = 0;
    for (i=0; i<10; i++) {
      _LATE2 = !_LATE2; // Toggle RE2
      _LATE3 = !_LATE3; // Toggle RE3
      Delay_MS(100);
    }
    _LATE2 = 0;
    _LATE3 = 0;
    tick = 0;           // Clear Tick
  }    
    _T1IF = 0;  // Clear Timer1 Interrupt flag
}
                        
//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Rotate left
byte Rotate_Left(byte *x, byte i)
{
  for (; i>0; i--)
    *x = (*x<<1)|(*x>>7);
    
  return (*x);
}

//----------------------------------------------------:Timer1 Init
void Timer1_Init(void)
{
  unsigned int config, period;

  CloseTimer1();					    // Close Timer1

  ConfigIntTimer1(T1_INT_ON);		// Config Int Timer1

  // Timer1 Control Register (T1CON) Bit Defines
  config = T1_ON & 				    // Timer1 ON	
           T1_IDLE_STOP & 		// stop operation during sleep
           T1_GATE_OFF & 		  // Timer Gate time accumulation disabled
           T1_PS_1_64 & 		  // Prescaler 1:64
           T1_SYNC_EXT_OFF &  // Do not synch external clk input
           T1_SOURCE_INT;			// Internal clock source
              
  period = 57604;					    // Set PR1 Register		

  OpenTimer1(config,period);	// Open Timer1
}
  
//----------------------------------------------------:Main
int main(void)
{
  unsigned int config;
  byte rl = 1, dout = 1;

  ADPCFG = 0xFF;    // ADC Input Off (PORTB)
  TRISB = 0;        // Set PORTB output
  _TRISE0 = 0;      // Set RE0 output
  _TRISE1 = 0;      // Set RE1 output
  _TRISE2 = 0;      // Set RE2 output
  _TRISE3 = 0;      // Set RE3 output

  LATB = 0;         // Clear PORTB
  _LATE0 = 0;       // Clear RE0
  _LATE1 = 0;       // Clear RE1

  Timer1_Init();    // Initialize Timer 1

  while (TRUE) {          
    if (dout < 0x40) {
      LATE = 0;         // Clear PORTE
      LATB = dout;      // Output PORTB   
    } else {
      LATB = 0;         // Clear PORTB
      LATE = dout>>6;   // Output RE0 or RE1
    }                  
    dout = Rotate_Left(&rl,1);
    Delay_MS(100);
  }
  
  return 0;
}
