/*
 * File      : EX05_01.c
 * Purpose   : Timer1 (Timer mode)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 04/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled , XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off

            
//----------------------------------------------------:Defines
#define TRUE              1


//----------------------------------------------------:Data types
typedef unsigned char byte;


//----------------------------------------------------:Global Variable
byte tick=0;


//----------------------------------------------------:Function prototype
void Delay_MS(unsigned int ms);


//----------------------------------------------------:Timer1 Interrupt
void _ISR _T1Interrupt(void)
{
  char i;
  
  if (++tick == 2) {
    _LATE2 = 1;
    _LATE3 = 0;
    for (i=0; i<10; i++) {
      _LATE2 = !_LATE2; // Toggle RE2
      _LATE3 = !_LATE3; // Toggle RE3
      Delay_MS(100);
    }
    _LATE2 = 0;
    _LATE3 = 0;
    tick = 0;           // Clear Tick
  }    
    _T1IF = 0;  // Clear Timer1 Interrupt flag
}
                        
//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Rotate left
byte Rotate_Left(byte *x, byte i)
{
  for (; i>0; i--)
    *x = (*x<<1)|(*x>>7);
    
  return (*x);
}

//----------------------------------------------------:Timer1 Init
void Timer1_Init(void)
{
  T1CONbits.TON = 0;    // Close Timer1
  
  // Config Interrupt Timer1
  IPC0bits.T1IP = 1;    // Set Timer1 Interrupt Priority Level
  IFS0bits.T1IF = 0;    // Clear Timer1 Interrupt Flag
  IEC0bits.T1IE = 1;    // Enable Timer1 interrupt

  // Timer1 Control Register (T1CON) Bit Defines  
  T1CONbits.TSIDL = 1;  // stop operation during sleep
  T1CONbits.TGATE = 0;  // Timer Gate time accumulation disabled
  T1CONbits.TCKPS = 2;  // Prescaler 1:64
  T1CONbits.TSYNC = 0;  // Do not synch external clk input
  T1CONbits.TCS = 0;		// Internal clock source
              
  PR1 = 57604;					// Set PR1 Register		

  T1CONbits.TON = 1;    // Timer1 ON	
}
  
//----------------------------------------------------:Main
int main(void)
{
  unsigned int config;
  byte rl = 1, dout = 1;

  ADPCFG = 0xFF;    // ADC Input Off (PORTB)
  TRISB = 0;        // Set PORTB output
  _TRISE0 = 0;      // Set RE0 output
  _TRISE1 = 0;      // Set RE1 output
  _TRISE2 = 0;      // Set RE2 output
  _TRISE3 = 0;      // Set RE3 output

  LATB = 0;         // Clear PORTB
  _LATE0 = 0;       // Clear RE0
  _LATE1 = 0;       // Clear RE1

  Timer1_Init();    // Initialize Timer 1

  while (TRUE) {          
    if (dout < 0x40) {
      LATE = 0;         // Clear PORTE
      LATB = dout;      // Output PORTB   
    } else {
      LATB = 0;         // Clear PORTB
      LATE = dout>>6;   // Output RE0 or RE1
    }                  
    dout = Rotate_Left(&rl,1);
    Delay_MS(100);
  }
  
  return 0;
}
