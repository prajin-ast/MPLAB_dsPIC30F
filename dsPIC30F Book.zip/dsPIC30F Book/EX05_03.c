/*
 * File      : EX05_03.c
 * Purpose   : Timer23 (32-bit Timer mode)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 08/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <timer.h>          // Timer module library functions 


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled , XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off

            
//----------------------------------------------------:Defines
#define TRUE              1


//----------------------------------------------------:Data types
typedef unsigned char byte;


//----------------------------------------------------:Function prototype
void Delay_MS(unsigned int ms);


//----------------------------------------------------:Timer3 Interrupt
void _ISR _T3Interrupt(void)
{
  char i;
  
  _LATE2 = 1;
  _LATE3 = 0;
  for (i=0; i<10; i++) {
    _LATE2 = !_LATE2; // Toggle RE2
    _LATE3 = !_LATE3; // Toggle RE3
    Delay_MS(100);
  }
  _LATE2 = 0;
  _LATE3 = 0;
  _T3IF = 0;          // Clear Timer3 Interrupt flag
}
                        
//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Rotate left
byte Rotate_Left(byte *x, byte i)
{
  for (; i>0; i--)
    *x = (*x<<1)|(*x>>7);
    
  return (*x);
}

//----------------------------------------------------:Timer23 Init
void Timer23_Init(void)
{
  unsigned int config;
  unsigned long period;

  CloseTimer23();               // Close Timer23

  // Initialize Timer23 Interrupt
  ConfigIntTimer23(T2_INT_ON);

  // Timer2 Control Register (T2CON) Bit Defines
  config = T2_ON &              // Timer2 ON
           T2_IDLE_STOP &       // stop operation during sleep
           T2_GATE_OFF &        // Timer Gate time accumulation disabled
           T2_PS_1_64 &          // Prescaler 1:64
           T2_32BIT_MODE_ON &   // Timer 2 and Timer 3 form a 32 bit Timer
           T2_SOURCE_INT;       // Internal clock source

  WriteTimer23(0);              // Set TMR2/3 Register
  period = 576037;              // PR2&PR3 Register (32 bit)
  OpenTimer23(config,period);   // Open Timer23
}

//----------------------------------------------------:Main
int main(void)
{
  unsigned int config;
  byte rl = 1, dout = 1;

  ADPCFG = 0xFF;    // ADC Input Off (PORTB)
  TRISB = 0;        // Set PORTB output
  _TRISE0 = 0;      // Set RE0 output
  _TRISE1 = 0;      // Set RE1 output
  _TRISE2 = 0;      // Set RE2 output
  _TRISE3 = 0;      // Set RE3 output

  LATB = 0;         // Clear PORTB
  _LATE0 = 0;       // Clear RE0
  _LATE1 = 0;       // Clear RE1

  Timer23_Init();   // Initialize Timer2/3 32-bit Timer

  while (TRUE) {          
    if (dout < 0x40) {
      LATE = 0;         // Clear PORTE
      LATB = dout;      // Output PORTB   
    } else {
      LATB = 0;         // Clear PORTB
      LATE = dout>>6;   // Output RE0 or RE1
    }                  
    dout = Rotate_Left(&rl,1);
    Delay_MS(100);
  }
  
  return 0;
}
