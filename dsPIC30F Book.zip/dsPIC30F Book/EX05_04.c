/*
 * File      : EX05_04.c
 * Purpose   : Clock (Timer 1 Module)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 09/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// LCD PIN
// GND -> LCD R/W
// RE0 -> LCD D4
// RE1 -> LCD D5
// RE2 -> LCD D6
// RE3 -> LCD D7
// RE4 -> LCD RS
// RE5 -> LCD E 

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <timer.h>          // Timer module library functions 
#include <stdio.h>          // standard header 


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled , XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off


//----------------------------------------------------:Library
#include "LIB_EX05_04_Time.C"     // Time Library
#include "LIB_LCD16x2.C"          // LCD Module Library 


//----------------------------------------------------:Defines
#define TRUE              1

  
//----------------------------------------------------:Main
int main(void)
{
  char buf[4];
  
  Timer1_Init();    // Initialize Timer 1
  LCDInit();        // Initialize the LCD display
  LCDClrscr();      // Clear screen

  Timer_Set(10,58,59);    // Set TIME start
  
  LCDPrintxy(1,1,0, "Timer1 Module..");
  LCDPrintxy(1,2,0, "TIME: ");

  while (TRUE) {
    if (dsp) {
      if (time_t1.hr <= 9) { 
        sprintf(buf,"0%d:",time_t1.hr);
      } else {
          sprintf(buf,"%d:",time_t1.hr);
        }
      LCDPrintxy(7,2,0, buf);       // Display hour
        
      if (time_t1.min <= 9) {
        sprintf(buf,"0%d:",time_t1.min); 
      } else {
          sprintf(buf,"%d:",time_t1.min); 
        }        
      LCDPrintxy(10,2,0, buf);      // Display minute
      
      if (time_t1.sec <= 9) { 
          sprintf(buf,"0%d",time_t1.sec); 
      } else {
          sprintf(buf,"%d",time_t1.sec); 
        }
      LCDPrintxy(13,2,0, buf);      // Display second
      
      dsp = 0;      // wait for set
    }      
  }
  
  return 0;
}
