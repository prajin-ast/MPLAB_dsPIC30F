/*
 * File      : EX05_05.c
 * Purpose   : Watchdog Timer
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 01/07/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>		// Generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);  // Sw Disabled, Mon Disabled, XT w/PLL 1x			

// Twdt = 2 ms*PrescaleA*PrescaleB = 2.048 s
_FWDT(WDT_ON &                  // Watchdog timer on
      WDTPSA_64 &               // Prescale A 1:64
      WDTPSB_16);               // Prescale B 1:16	


//----------------------------------------------------:delay_ms
// Delay 1 ms (XT w/PLL 1x)
void delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
  for (i=0; i<182; i++)
    Nop();                // delay 1 mch cycle        
}

//----------------------------------------------------:Main
int main(void)
{
  unsigned int i=0;

  _TRISD0 = 0;              // Set bit RD0 output

  while (i++<5) {
    _LATD0 = 0;           // Clear bit RD0
    delay_ms(1000);       // Delay 1 s
    ClrWdt();             // Clear WDT
    _LATD0 = 1;           // Set bit RD0
    delay_ms(1000);       // Delay 1 s
    ClrWdt();             // Clear WDT
  }

  while (1) {               // Wait WDT Reset 
    _LATD0 = 1;           // Set bit RD0
  }
  
  return 0;
}
