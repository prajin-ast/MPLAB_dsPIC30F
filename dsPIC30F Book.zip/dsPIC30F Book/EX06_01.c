/*
 * File      : EX06_01.c
 * Purpose   : UART1 Receive data in main loop
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 10/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// USART PIN (dsPIC30F2010)
// Normal pins (Use) 
// U1RTX -> RF2, U1TX -> RF3
// ALT pins 
// U1ATX -> RC13, U1ARX -> RC14

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC
#include <uart.h>               // uart module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Calc Baud Rate Generator
#define Fcy             7372800.0                 // Fosc 7.3728MHz
#define BAUD_RATE       9600.0                    // Baud Rate 9600 bps
#define BAUD_RATE_GEN   (Fcy/(16.0*BAUD_RATE))-1  // Baud Rate Generator 


//----------------------------------------------------:Uart1_Init
// Initialize UART1
void Uart1_Init(void)
{
  unsigned int configU1MODE, configU1STA, BaudRate;	

  CloseUART1();                       // Close UART1

  configU1MODE = UART_EN &            // Module enable
                 UART_IDLE_CON &      // Work in IDLE mode
                 //UART_RX_TX &         // Communication through the normal pins
                 //UART_ALTRX_ALTTX &	  // Communication through ALT pins
                 UART_DIS_WAKE &      // Disable Wake-up on START bit Detect during SLEEP Mode bit
                 UART_DIS_LOOPBACK &	// Loop back disabled
                 UART_DIS_ABAUD &     // Input to Capture module from ICx pin
                 UART_NO_PAR_8BIT &	  // no parity 8 bit		
                 UART_1STOPBIT;       // 1 stop bit

  configU1STA = UART_INT_TX_BUF_EMPTY &  // Interrupt on TXBUF becoming empty
                UART_TX_PIN_NORMAL &     // UART TX pin operates normally
                UART_INT_RX_CHAR &       // Interrupt on every char received
                UART_ADR_DETECT_DIS &    // address detect disable	
                UART_RX_OVERRUN_CLEAR;   // Rx buffer Over run status bit clear		


  BaudRate = BAUD_RATE_GEN;		// BaudRate 9600 pbs	

  // Open UART1
  OpenUART1(configU1MODE, configU1STA, BaudRate);
}

//----------------------------------------------------:Uart1_PrintStr
// print string to uart1
void Uart1_PrintStr(unsigned char *str_uart)
{
  putsUART1 ((unsigned int *)str_uart);
  while (BusyUART1());        // wait for transmission to complete
}

//----------------------------------------------------:Main
int main(void) 
{
  unsigned char ch;

  Uart1_Init();       // Initialize the UART1
  _TRISD0 = 0;        // Set RD0 output
  _LATD0 = 0;         // Clear RD0

  Uart1_PrintStr("\fUART Polling..\n\r");
  Uart1_PrintStr("Press Key for RD0 Toggle..\n\r");
  
  for(;;) {
    while (DataRdyUART1()) {  // Wait for Receive buffer has a data to be read
      ch = ReadUART1();       // Get character in UART RX    
      if (ch != 13) {         // Check Enter Key           
        putcUART1(ch);        // Sent character to UART TX
        _LATD0 = !_LATD0;     // Toggle bit
        if (_LATD0 == 1) {
          Uart1_PrintStr("  : RD0 High.\n\r");
        } else {
          Uart1_PrintStr("  : RD0 Low.\n\r");
        }
      } else {
        putsUART1((unsigned int *)"\n\r");  // Sent new line & return to UART TX
      }                  
      while (BusyUART1());    // wait for transmission to complete
    }      
  }

  return 0;
}
