/*
 * File      : EX06_02.c
 * Purpose   : TUART1 Receive in interrupt
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 11/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// USART PIN (dsPIC30F2010)
// Normal pins (Use)
// U1RTX -> RF2, U1TX -> RF3
// ALT pins
// U1ATX -> RC13, U1ARX -> RC14

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC
#include <uart.h>               // uart module
#include <string.h>             // String.h standard header


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled,XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Calc Baud Rate Generator
#define Fcy             7372800.0                 // Fosc 7.3728MHz
#define BAUD_RATE       9600.0                    // Baud Rate 9600 bps
#define BAUD_RATE_GEN   (Fcy/(16.0*BAUD_RATE))-1  // Baud Rate Generator 

#define KeyEnter        13                        // Key Code


//----------------------------------------------------:Global variables
// Received data is stored in array Buf
char Buf[80];                   // Received data is stored in array Buf
char ch, c_buf=0;


//----------------------------------------------------:U1RX ISR
// UART1 Receiver Interrupt Service Routine
void _ISR _U1RXInterrupt(void)
{
  _U1RXIF = 0;    // Clear interrupt flag RX
  
  // Read the receive buffer till atleast one or more character can be read
  while (DataRdyUART1()) {
    ch = ReadUART1();     // Read buffer rx    
    putcUART1(ch);        // print character rx
    Buf[c_buf++] = ch;    // wirte to buf
  }
}

//----------------------------------------------------:U1TX ISR
// UART1 Transmitter Interrupt Service Routine
void _ISR _U1TXInterrupt(void)
{
  _U1TXIF = 0;  // Clear interrupt flag TX
}

//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Uart1_Init
// Initialize UART1
void Uart1_Init(void)
{
  unsigned int U1MODEvalue, U1STAvalue, BaudRate;	

  CloseUART1();			// Close UART1

  // Config Interrupt UART1
  ConfigIntUART1(UART_RX_INT_EN &         // Receive interrupt enabled
                 UART_RX_INT_PR6 &        // Priority RX interrupt 6
                 UART_TX_INT_EN &         // transmit interrupt enabled
                 UART_TX_INT_PR2 );       // Priority TX interrupt 2

  U1MODEvalue = UART_EN &                 // Module enable
                UART_IDLE_CON &           // Work in IDLE mode
                //UART_RX_TX &              // Communication through the normal pins
                //UART_ALTRX_ALTTX &        // Communication through ALT pins								
                UART_DIS_WAKE &           // Disable Wake-up on START bit Detect during SLEEP Mode bit
                UART_DIS_LOOPBACK &       // Loop back disabled
                UART_DIS_ABAUD &          // Input to Capture module from ICx pin
                UART_NO_PAR_8BIT &        // no parity 8 bit		
                UART_1STOPBIT;            // 1 stop bit

  U1STAvalue	= UART_INT_TX_BUF_EMPTY &   // Interrupt on TXBUF becoming empty
                UART_TX_PIN_NORMAL &      // UART TX pin operates normally
                UART_INT_RX_CHAR &        // Interrupt on every char received
                UART_ADR_DETECT_DIS &     // address detect disable	
                UART_RX_OVERRUN_CLEAR;    // Rx buffer Over run status bit clear		

  BaudRate = BAUD_RATE_GEN;		// BaudRate 9600 pbs

  // Open UART1
  OpenUART1(U1MODEvalue, U1STAvalue, BaudRate);
}

//----------------------------------------------------:Uart1 PrintStr
// print string to uart1
void Uart1_PrintStr(unsigned char *str_uart)
{
  putsUART1 ((unsigned int *)str_uart);
  while (BusyUART1());        // wait for transmission to complete
}

//----------------------------------------------------:Main
int main(void) 
{
  unsigned char msg01[] = "\fMicrochip dsPIC MPLAB C30\n\rInput String:  ";
  unsigned char msg02[] = "\n\rBuf:  ";  

  Uart1_Init();             // Initialize the UART1
  _TRISD0 = 0;              // Set direction control RD0 Output
  _LATD0 = 0;               // Clear RD0
  
  Uart1_PrintStr(msg01);    // Print msg01
    
  for(;;) {
    _LATD0 = !_LATD0;       // Toggle RD0
    Delay_MS(100);
    
    if (ch == KeyEnter) {
      Uart1_PrintStr(msg02);  // Print msg02
      Uart1_PrintStr(Buf);    // Print Buffer
      Uart1_PrintStr("\n\rInput String:  "); // Print String
      memset(Buf,'\0',sizeof(Buf)); // Set all location to zero 
      ch = '\0';              // Clear ch
      c_buf = 0;              // Clear count buffer
    }      
	}
	
  return 0;
}

