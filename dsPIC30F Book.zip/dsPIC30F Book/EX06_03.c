/*
 * File      : EX06_03.c
 * Purpose   : UART1/HyperTerminal
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 12/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// USART PIN (dsPIC30F2010)
// Normal pins (Use) 
// U1RTX -> RF2, U1TX -> RF3
// ALT pins
// U1ATX -> RC13, U1ARX -> RC14

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Global variables
char led_status[4] = {0,0,0,0};
char ch_menu = 0;

//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library


//----------------------------------------------------:RX_ISR
void _ISR _U1RXInterrupt(void) 
{
  char ch;
  
  _U1RXIF = 0;
  ch = ReadUART1();         // Read buffer rx    
  if (ch >= '1' && ch <= '4') {  
    switch(ch) {
      case '1': _LATE0 = !_LATE0;         // Toggle bit
                led_status[0] = _LATE0;   // Save Status
                break;
      case '2': _LATE1 = !_LATE1;
                led_status[1] = _LATE1;
                break;
      case '3': _LATE2 = !_LATE2;
                led_status[2] = _LATE2;
                break;
      case '4': _LATE3 = !_LATE3;
                led_status[3] = _LATE3;
                break;
    }
    ch_menu = 1;    // Set Menu for Change Status        
  }
}

//----------------------------------------------------:TX_ISR
void _ISR _U1TXInterrupt(void) 
{ 
  _U1TXIF = 0; 
}

//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Menu Display
void Menu_Display(void)
{
  char buf[25], i;

  Uart1PrintStr("\f+-----------------+\n\r");
  Uart1PrintStr("|  HyperTerminal  |\n\r");
  Uart1PrintStr("|  Menu Command   |\n\r");
  Uart1PrintStr("+-----------------+\n\r");
  
  for (i=1; i<5; i++) {
    if (led_status[i-1]) {   
      sprintf(buf,"| %d : LED %d : ON  |\n\r",i,i);
    } else {
      sprintf(buf,"| %d : LED %d : OFF |\n\r",i,i);
    }          
    Uart1PrintStr(buf);
  }

  Uart1PrintStr("+-----------------+\n\r");
  Uart1PrintStr("|Command Number : ");  
}

//----------------------------------------------------:Main
int main(void) 
{
  unsigned char ch;

  Uart1Init(1);        // Initialize the UART1, Interrupt ON
  TRISE = 0;          // Set RE output
  _TRISD0 = 0;        // Set RD0 output
  _LATD0 = 0;         // Clear RD0
  LATE = 0;           // Clear RE
  
  Menu_Display();     // Display Menu
  
  for(;;) {
    _LATD0 = !_LATD0;   // Toggle bit
    Delay_MS(100);
    if (ch_menu) {      // Check Menu Change
      Menu_Display();
      ch_menu = 0;
    }      
  }

  return 0;
}
