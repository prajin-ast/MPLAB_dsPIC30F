/*
 * File      : EX07_01.c
 * Purpose   : IC1 (Frequency use Timer2)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 21/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// Input Capture PIN (dsPIC30F2010)
// IC1 -> RD0, IC2 -> RD1
// IC7 -> RB4, IC8 -> RB5
// USART PIN (dsPIC30F2010)
// Normal pins (Use) 
// U1RTX -> RF2, U1TX -> RF3

//----------------------------------------------------:Includes
#include <p30fxxxx.h>     // generic header file for dsPIC
#include <incap.h>        // Input Capture module
#include <timer.h>        // Timer module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off


//----------------------------------------------------:Global variables
char count_t2 = 0;              // Counter for Timer2
unsigned int count_freq = 0;    // Counter for Frequency
char hook_1s = 0;               // flag set 1 second


//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library


//----------------------------------------------------:IC1 ISR
void _ISR _IC1Interrupt(void)
{
  ++count_freq;
  _IC1IF = 0;             // Clear Interrupt flag
}

//----------------------------------------------------:Timer2 ISR
void _ISR _T2Interrupt(void)
{
  if (++count_t2 == 2)
    hook_1s = 1;        // Set Display
  
  _T2IF = 0;            // Clear Interrupt flag
}

//----------------------------------------------------:IC1_Init
// Initialize Input Capture1
void IC1_Init(void)
{
  unsigned int config, period;
  
  CloseCapture1();              // CloseCapture 1
  
  // ConfigIntCapture1
  ConfigIntCapture1(IC_INT_ON); // Input Capture Enable  

  // OpenCapture1
  config = IC_IDLE_CON &        // IC operate in sleep mode
           IC_TIMER2_SRC &      // Timer2 is the clock source for Capture
           IC_INT_1CAPTURE &    // Interrupt on first Capture
           IC_EVERY_FALL_EDGE;  // Every falling edge
           
  OpenCapture1(config);
  
  CloseTimer2();                // Close Timer2
  
  ConfigIntTimer2(T2_INT_ON);   // Timer2 Interrupt Enable

  // Timer2 Control Register (T2CON) Bit Defines
  config = T2_ON &              // Timer2 ON
           T2_IDLE_STOP &       // stop operation during sleep
           T2_GATE_OFF &        // Timer Gate time accumulation disabled
           T2_PS_1_64 &          // Prescaler 1:64
           T2_32BIT_MODE_OFF &  // Timer 32 bit Timer OFF
           T2_SOURCE_INT;       // Internal clock source
  
  period = 57604;               // PR2 Register
  OpenTimer2(config,period);    // Open Timer2
}

//----------------------------------------------------:Main
int main(void) 
{  
  char sbuf[25];
  
  _TRISD0 = 1;      // Set RD0 input for IC1
  
  IC1_Init();       // Initialize Input Capture1
  Uart1Init(0);     // Initialize the UART1, Interrupt OFF
  
  for(;;) {
    if (hook_1s) {
      Uart1PrintStr("\f+------------------------+\n\r");
      Uart1PrintStr("+ Frequency Measurements +\n\r");
      Uart1PrintStr("+------------------------+\n\r");
      sprintf(sbuf, " Frequency: %u Hz",count_freq);
      Uart1PrintStr(sbuf);
      // Clear flag variables 
      hook_1s = 0;
      count_t2 = 0;
      count_freq = 0;
    }
  }

  return 0;
}
