/*
 * File      : EX07_03.c
 * Purpose   : IC1 (External Interrupt)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 21/07/08
 * Ref.      :  
*/

//----------------------------------------------:NOTE
// Input Capture PIN (dsPIC30F2010)
// IC1 -> RD0, IC2 -> RD1
// IC7 -> RB4, IC8 -> RB5

//----------------------------------------------:Includes
#include <p30fxxxx.h>     // generic header file for dsPIC
#include <incap.h>        // Input Capture module


//----------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);    // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                   // Watchdog timer off


//----------------------------------------------:Function Prototype
void Delay_MS(unsigned int ms);


//----------------------------------------------:IC7 ISR
void _ISR _IC7Interrupt(void)
{
  _LATE0 = 1;    
  Delay_MS(100);
  _LATE0 = 0;
  
  _IC7IF = 0;       // Clear Interrupt flag
}

//----------------------------------------------:IC8 ISR
void _ISR _IC8Interrupt(void)
{
  _LATE1 = 1;  
  Delay_MS(100);
  _LATE1 = 0;
      
  _IC8IF = 0;       // Clear Interrupt flag
}

//----------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------:IC7_IC8_Init
// Initialize Input Capture7, Input Capture8
void IC7_IC8_Init(void)
{
  unsigned int config;
  
  CloseCapture7();              // Close Capture 7
  CloseCapture8();              // Close Capture 8
  
  // ConfigIntCapture7/8
  ConfigIntCapture7(IC_INT_ON); // Input Capture Enable  
  ConfigIntCapture8(IC_INT_ON); // Input Capture Enable  
  
  // OpenCapture7
  config = IC_IDLE_CON &        // IC operate in sleep mode
           IC_INT_1CAPTURE &    // Interrupt on first Capture
           IC_EVERY_FALL_EDGE;  // Every falling edge
           
  OpenCapture7(config);
  
  // OpenCapture8
  config = IC_IDLE_CON &        // IC operate in sleep mode
           IC_INT_1CAPTURE &    // Interrupt on first Capture
           IC_EVERY_RISE_EDGE;  // Every rising edge
  
  OpenCapture8(config);
}

//----------------------------------------------:Main
int main(void) 
{    
  // Set RB4,RB5 input for IC7, IC8
  _TRISB4 = 1;        
  _TRISB5 = 1;        
  // Off analog input on RB4,RB5
  _PCFG4 = 1;         
  _PCFG5 = 1;

  TRISE = 0;          // Set PORTE output
  LATE = 0x0028;      // RE3, RE5 -> ON
  
  IC7_IC8_Init();     // Initialize Input Capture7/8
    
  for(;;) {
    _LATE2 = !_LATE2; // Toggle
    _LATE3 = !_LATE3;
    _LATE4 = !_LATE4;
    _LATE5 = !_LATE5;
    Delay_MS(1000);
  }

  return 0;
}
