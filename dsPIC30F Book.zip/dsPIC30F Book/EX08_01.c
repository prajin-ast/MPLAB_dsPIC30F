/*
 * File      : EX08_01.c
 * Purpose   : Output Compare Module
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 23/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// Output Compare PIN (dsPIC30F2010)S
// OC1 -> RD0,	OC2 -> RD1

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC
#include <timer.h>              // Timer module
#include <OutCompare.h>         // Output Compare module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:OC1_Init
// Initialize Output Compare
void OC1_Init(void)
{
  unsigned int vToggle, period;
  
  CloseOC1();                 // CloseOC1

  vToggle = 0x0FFF;           // Value for Toggle

  // Open Output Compare 1
  OpenOC1(OC_IDLE_STOP &      // stop in idle mode
          OC_TIMER2_SRC &     // Timer2 is the clock source for OutputCompare1
          OC_TOGGLE_PULSE,    // Compare1 toggels  OCx pin
          0x0000,             // OCxRS Data Secondary Register
          vToggle             // OCxR Data Main Register				
          );

  CloseTimer2();                // Close Timer2
  
  // Timer2 Control Register (T2CON) Bit Defines  
  period = vToggle;               // PR2 = OCxR
  // Open Timer2
  OpenTimer2(T2_ON &              // Timer2 ON
             T2_IDLE_STOP &       // stop operation during sleep
             T2_GATE_OFF &        // Timer Gate time accumulation disabled
             T2_PS_1_256 &        // Prescaler 1:256
             T2_32BIT_MODE_OFF &  // Timer 32 bit Timer OFF
             T2_SOURCE_INT        // Internal clock source
             ,period);            // PR2 Register
}

//----------------------------------------------------:Main
int main(void)
{
    _TRISD0 = 0;      // Set RD0 pin output
    OC1_Init();       // Initialize Output Compare

    for (;;)          // loop nothing
    ;

    return 0;
}
