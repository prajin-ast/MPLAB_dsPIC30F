/*
 * File      : EX08_02.c
 * Purpose   : Output Compare Module
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 23/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// Output Compare PIN (dsPIC30F2010)S
// OC1 -> RD0,	OC2 -> RD1

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC
#include <OutCompare.h>         // Output Compare module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:OC1 ISR
// OC1 Interrupt Service Routine (pin RD0)
void _ISR _OC1Interrupt(void)
{
  _LATE1 = !_LATE1;   // Toggle RE1
  _OC1IF = 0;         // Clear Interrupt Flag
}

//----------------------------------------------------:OC1_Init
// Initialize Output Compare
void OC1_Init(void)
{
  unsigned int pulse_start,pulse_stop;	

  CloseOC1();                 // CloseOC1

  // Configure OC1 interrupt
  ConfigIntOC1(OC_INT_ON);    // Interrupt Enable

  // Configure OC1 module for required pulse width
  pulse_start = 0x0400;       // OCxR Data Main Register
  pulse_stop = 0x0600;        // OCxRS Data Secondary Register

  // Open OC1
  OpenOC1(OC_IDLE_CON &       // continue operation in idle mode
          OC_TIMER3_SRC &     // Timer3 is the clock source for OutputCompare1
          OC_CONTINUE_PULSE,  // Generates Continuous Output pulse on OCx Pin
          pulse_stop,         // OCxRS Data Secondary Register
          pulse_start         // OCxR Data Main Register				
          );

  // Configure Timer3
  TMR3 = 0;             // Clear Timer 3
  PR3 = 0x0800;         // Set PR3 Register
  T3CON = 0x8030;       // Timer3 ON, Prescaler 1:256

  // Configure Timer1
  TMR1 = 0x0;           // Clear Timer 1
  PR1 = 0xffff;         // Set PR1 Register
  T1CON = 0x8030;       // Timer1 ON, Prescaler 1:256
}

//----------------------------------------------------:Main
int main(void)
{
  _TRISE0 = 0;      // Set RE0/RE1 output
  _TRISE1 = 0;
  _TRISD0 = 0;      // Set RD0 output
  
  _LATE0 = 0;       // Clear RE0/RE1
  _LATE1 = 0;                     
  
  OC1_Init();       // Initialize Output Compare
	
  for(;;) {
	  _LATE0 = !_LATE0;     // Toggle RE0  
    
    while (TMR1 < 0xFFFF) // Delay Timer1
      asm("nop");
  }
    
  return 0;
}
