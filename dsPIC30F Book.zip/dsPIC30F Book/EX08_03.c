/*
 * File      : EX08_03.c
 * Purpose   : Servo Motor Control (OC Module)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 23/07/08
 * Ref.      :  
*/

//----------------------------------------------------:NOTE
// Output Compare PIN (dsPIC30F2010)S
// OC1 -> RD0,	OC2 -> RD1

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC
#include <OutCompare.h>         // Output Compare module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Delay_MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();              // delay 1 mch cycle
}

//----------------------------------------------------:Servo_Open
void Servo_Open()
{
  CloseOC1();
  OpenOC1(OC_IDLE_CON &       // continue operation in idle mode
          OC_TIMER2_SRC &     // Timer2 is the clock source for OutputCompare1
          OC_PWM_FAULT_PIN_DISABLE, // PWM Mode on OCx, fault pin disabled
          0,                  // OCxRS Data Secondary Register
          0                   // OCxR Data Main Register				
				  );

  TMR2 = 0x0000;      // Clear Timer 2
  T2CON = 0x8030;     // Timer2 ON, Prescaler 1:256
}

//----------------------------------------------------:Servo_Left
void Servo_Left(void)
{  
  PR2 = 604;
  SetDCOC1PWM(29);    // Pulse High 1 ms
}

//----------------------------------------------------:Servo_Right
void Servo_Right(void)
{
  PR2 = 633;
  SetDCOC1PWM(58);    // Pulse High 2 ms    
}

//----------------------------------------------------:Servo_Middle
void Servo_Middle(void)
{
  PR2 = 618;
  SetDCOC1PWM(43);    // Pulse High 1.5 ms
}

//----------------------------------------------------:Main
int main(void)
{
  _TRISE0 = 0;        // Set RE0/RE1/RE2 output
  _TRISE1 = 0;
  _TRISE2 = 0;      
  _LATE0 = 0;         // Clear RE0/RE1/RE2
  _LATE1 = 0;
  _LATE2 = 0;
  
  Servo_Open();       // Open Servo

  for (;;) {
    _LATE0 = 1;    
    Servo_Right();    // Right
    Delay_MS(2000);
    _LATE0 = 0;
    
    _LATE1 = 1;
    Servo_Left();     // Left
    Delay_MS(2000);
    _LATE1 = 0;

    _LATE2 = 1;
    Servo_Middle();   // Middle
    Delay_MS(2000);
    _LATE2 = 0;
  }

	return 0;
}
