/*
 * File      : EX09_02.c
 * Purpose   : ADC (Simultaneous Sampling mode)
             : 4 Channels, Auto-Sample Start
             : Tad Conversion Start Simultaneous Sampling Code
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 18/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <adc10.h>          // 10bit ADC module library functions


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Global variables
unsigned int ADC_Value[4];


//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Initialize ADC 10bit
void ADC10_Init(void)
{
  unsigned int config1, config2, config3;
  unsigned int configport, configscan;
  unsigned int channel;
  
  CloseADC10();   // Turn off A/D
  
  // Configure ADCON1 register
  config1 = ADC_MODULE_OFF &          // A/D Converter off
            ADC_IDLE_CONTINUE &       // A/D Operate in Idle mode
            ADC_FORMAT_INTG &         // A/D data format integer
            ADC_CLK_AUTO &            // sampling/conversion (Auto convert)
            ADC_SAMPLE_SIMULTANEOUS & // Simultaneous sampling
            ADC_AUTO_SAMPLING_ON &    // Auto sampling Select
            ADC_SAMP_ON;              // sample/hold amplifiers are sampling
            
  // Configure ADCON2 register
  config2 = ADC_VREF_AVDD_AVSS &    // Vref+ is AVdd and Vref- is AVss
            ADC_SCAN_OFF &          // Do notScan Input
            ADC_CONVERT_CH_0ABC &   // A/D channels utilised
            ADC_SAMPLES_PER_INT_4 & // interrupt at 4th sample
            ADC_ALT_BUF_OFF &       // Buffer 16-word buffer
            ADC_ALT_INPUT_OFF;      // use MUXA only
            
  // Configure ADCON2 register
  config3 = ADC_SAMPLE_TIME_3 &     // A/D Auto Sample Time 3 Tad
            ADC_CONV_CLK_SYSTEM &   // Clock Source Clock derived from system clock
            ADC_CONV_CLK_3Tcy2;     // A/D Conversion Clock Select bits
  
  // Configure ADCHS register
  channel = ADC_CH0_POS_SAMPLEA_AN3 &       // A/D Chan 0 pos i/p sel for SAMPLE A is AN3
            ADC_CH0_NEG_SAMPLEA_NVREF &     // A/D Chan 0 neg i/p sel for SAMPLE A is -Vref
            ADC_CHX_POS_SAMPLEA_AN0AN1AN2 & // A/D Chan A B C pos i/p sel for SAMPLE A are AN0, 1 and 2
            ADC_CHX_NEG_SAMPLEA_NVREF;      // A/D CHA, CHB, CHC neg input is VREF-

  // RB0, RB1, RB2 & RB3 = analog
  configport = 0xFFF0;  // ADPCFG register
  
  // Configure ADCSSL register
  configscan = SCAN_NONE;             // Skip AN0-AN15 for Input Scan
    
  // configures the ADC
  OpenADC10(config1, config2, config3, configport, configscan);
  // sets the positive and negative inputs for the sample multiplexers            
  SetChanADC10(channel);
}

//----------------------------------------------------:ADC10 UART1 Display
void ADC10_Uart1Dsp(void)
{
  char buf[15];

  Uart1PrintStr("\f+----------------------------+\n\r");
  Uart1PrintStr("+ 10-bit ADC: Converting 4CH +\n\r");
  Uart1PrintStr("+ Simultaneous Sampling mode +\n\r");
  Uart1PrintStr("+----------------------------+\n\r");
  sprintf(buf,"+ CH0 = %u\n\r",ADC_Value[1]);
  Uart1PrintStr(buf);
  sprintf(buf,"+ CH1 = %u\n\r",ADC_Value[2]);
  Uart1PrintStr(buf);
  sprintf(buf,"+ CH2 = %u\n\r",ADC_Value[3]);
  Uart1PrintStr(buf);
  sprintf(buf,"+ CH3 = %u\n\r",ADC_Value[0]);
  Uart1PrintStr(buf);
}


//----------------------------------------------------:Main
int main(void)
{
  unsigned int count, *adcptr;
  
  Uart1Init(0);     // Initialize UART1 Disable Interrupt
  ADC10_Init();     // Initialize ADC 10bit
    
  _ADON = 1;        // turn ADC ON
  
  for (;;) {              // Loop forever
    adcptr = &ADCBUF0;    // Initialize ADCBUF pointer
    
    _ADIF = 0;            // Clear interrupt
    while (!_ADIF);       // Convert done?
    
    for (count=0; count<4; count++) {
      ADC_Value[count] = *adcptr++;
    }
    ADC10_Uart1Dsp();
    Delay_MS(1000);
  }
  
	return 0;
} 
