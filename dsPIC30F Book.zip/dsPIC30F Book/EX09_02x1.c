/*
 * File      : EX09_02x.c
 * Purpose   : ADC (Simultaneous Sampling mode)
             : 4 Channels, Auto-Sample Start
             : Tad Conversion Start Simultaneous Sampling Code
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 18/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <adc10.h>          // 10bit ADC module library functions


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Global variables
unsigned int ADC_Value[4];


//----------------------------------------------------:Library
#include "LIB_LCD16x2.C"          // LCD16x2 Module Library


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Initialize ADC 10bit
void ADC10_Init(void)
{
  unsigned int config1, config2, config3;
  unsigned int configport, configscan;
  unsigned int channel;
  
  CloseADC10();   // Turn off A/D
  
  // SIMASM bit = 1 implies... Simultaneous sampling
  // ASAM = 1 for auto sample after convert
  // SSRC = 111 for 3Tad sample time
  config1 = 0x00EC;     // ADCON1 register

  // CHPS = 1x implies simultaneous...
  // sample CH0 to CH3 
  // SMPI = 0011 for interrupt after 4 converts
  config2 = 0x030C;      // ADCON2 register    
 
  // Auto Sampling 3 Tad, Tad = internal 2 Tcy
  config3 = 0x0302;      // ADCON3 register
 
  // Connect AN3 as CH0 input
  channel = 3;          // ADCHS register

  // RB0, RB1, RB2 & RB3 = analog
  configport = 0xFFF0;  // ADPCFG register
  
  // Skip ANx for input scan               
  configscan = 0;        // ADCSSL register
    
  // configures the ADC
  OpenADC10(config1, config2, config3, configport, configscan);
  // sets the positive and negative inputs for the sample multiplexers            
  SetChanADC10(channel);
}

void ADC10_LCDDsp(void)
{
  char buf[10];

  LCDClrscr(); 
  sprintf(buf,"CH0=%u",ADC_Value[1]);
  LCDPrintxy(1,1,0, buf);
  sprintf(buf,"CH1=%u",ADC_Value[2]);
  LCDPrintxy(9,1,0, buf);
  sprintf(buf,"CH2=%u",ADC_Value[3]);
  LCDPrintxy(1,2,0, buf);
  sprintf(buf,"CH3=%u",ADC_Value[0]);
  LCDPrintxy(9,2,0, buf);
}  

//----------------------------------------------------:Main
int main(void)
{
  unsigned int count, *adcptr;
  
  LCDInit();          // Initialize the LCD display
  ADC10_Init();       // Initialize ADC 10bit
    
  _ADON = 1;          // turn ADC ON
  
  for (;;) {              // Loop forever
    adcptr = &ADCBUF0;    // Initialize ADCBUF pointer
    
    _ADIF = 0;            // Clear interrupt
    while (!_ADIF);       // Convert done?
    
    for (count=0; count<4; count++) {
      ADC_Value[count] = *adcptr++;
    }
    ADC10_LCDDsp();
    Delay_MS(1000);
  }
  
	return 0;
} 
