/*
 * File      : EX09_03.c
 * Purpose   : ADC (Simultaneous Sampling mode)
             : 4 Channels, Auto-Sample Start
             : Tad Conversion Start Simultaneous Sampling Code
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 10/03/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>   // generic header file for dsPIC
#include <stdlib.h>     // for div, div_t

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Global variables
unsigned int ADC_Value[4];


//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library
#include "LIB_ADC10.C"          // ADC10 Module Library


//----------------------------------------------------:Delay MS
// Delay 1 ms (XT w/PLL 4x)
void Delay_MS(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:ADC10 UART1 Display
void ADC10_Uart1Dsp(void)
{
  float voltage;
  unsigned char i, j;
  char buf[40];
  
  div_t V;      // Struct for variables div function

  Uart1PrintStr("\f+----------------------------+\n\r");
  Uart1PrintStr("+ 10-bit ADC: Converting 4CH +\n\r");
  Uart1PrintStr("+ Simultaneous Sampling mode +\n\r");
  Uart1PrintStr("+----------------------------+\n\r");

  for (i=0; i<4; i++) {
    // Calc Voltage
    voltage = ((float)ADC_Value[i])*5.0;
    // Use div function
    V = div(voltage, 1023);   
    
    // Set Analog buffer
    if (i==0) j = 3; else j = i-1;
    
    sprintf(buf,"+ AN%u (ADC): %u  ,V: %d.%d V\n\r",j, ADC_Value[i], V.quot,V.rem);
    Uart1PrintStr(buf);
    Uart1PrintStr("+----------------------------+\n\r");    
  }
}

//----------------------------------------------------:Main
int main(void)
{
  unsigned int count, *adcptr;
  
  Uart1Init(0);     // Initialize UART1 Disable Interrupt
  ADC10Init();      // Initialize ADC 10bit
    
  _ADON = 1;        // turn ADC ON
  
  for (;;) {              // Loop forever
    adcptr = &ADCBUF0;    // Initialize ADCBUF pointer
    
    _ADIF = 0;            // Clear interrupt
    while (!_ADIF);       // Convert done?
    
    for (count=0; count<4; count++) {
      ADC_Value[count] = *adcptr++;
    }
    ADC10_Uart1Dsp();
    Delay_MS(1000);
  }
  
	return 0;
} 
