/*
 * File      : EX10_02.c
 * Purpose   : Write&Erase 16 data word of data EEPROM Memory
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 17/11/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);       // Sw Disabled, Mon Disabled, XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Code Protect Disabled


//----------------------------------------------------:delay_ms
// Delay 1 ms (XT w/PLL 1x)
void delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
  for (i=0; i<182; i++)
    Nop();                  // delay 1 mch cycle
}

//----------------------------------------------------:RTSP_ProgramErase
// RTSP Program and Erase operations
void RTSP_ProgramErase(unsigned int cmd)
{
  // NVMCON Reg. Values for RTSP Program and Erase Operations
  NVMCON = cmd;     // Command NVMCON value
  NVMKEY = 0x55;    // Write the KEY sequence
  NVMKEY = 0xAA;          
  _WR = 1;          // Start the erase cycle
  while (_WR)       // wait for erase cycle is complete
    ;  
}  

//----------------------------------------------------:EraseRowEE
// Erase one row EEPROM
void EraseRowEE(unsigned int addr)
{
  // Set up a pointer to the EEPROM location to be erased.
  NVMADR = addr;      // NVM Address bits <15:0>
  NVMADRU = 0x7F;     // NVM Address bits <23:16>c

  // Setup NVMCON to erase one word of data EEPROM  
  RTSP_ProgramErase(0x4045);
}

//----------------------------------------------------:WriteRowEE
// Write one row EEPROM
int WriteRowEE(unsigned int addr, unsigned int *dat)
{  
  int i;
  
  // Set up a pointer to the EEPROM location to be write.
  TBLPAG = 0x7F;                // Table Page Register
 
  for (i=0; i<16; i++) {
    WREG1 = *dat++;             // data
    WREG0 = addr;               // address to write data			
    __asm__("TBLWTL	W1,[W0]");  // write data		
    addr +=2;                   // even address boundary
  }
  
  // Setup NVMCON to write one word of data EEPROM  
  RTSP_ProgramErase(0x4005);
    
  return 0;
}

//----------------------------------------------------:Main Functions
int main(void) 
{
  unsigned int data[16]= {0x1000,0x2000,0x3000,0x4000,0x5000,
                          0x6000,0x7000,0x8000,0x9000,0xA000,
                          0xB000,0xC000,0xD000,0xE000,0xF000,
                          0xFF00};
                         	
  WriteRowEE(0xFC00,&data);   // Write 16 data words of EEPROM
  delay_ms(10);               // delay 10ms
  EraseRowEE(0xFC00);         // Erasing 16 data words of EEPROM
    
  while (1)                   // loop nothing
    ;		
								
  return 0;
}
