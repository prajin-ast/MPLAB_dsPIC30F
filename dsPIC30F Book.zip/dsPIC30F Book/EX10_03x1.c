/*
 * File      : EX10_03x1.c
 * Purpose   : Reading the Data EEPROM Memory
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 17/11/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);       // Sw Disabled, Mon Disabled, XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Code Protect Disabled


#include "LIB_EEPROM.C"         // EEPROM Library 

//----------------------------------------------------:ReadEE
// Read Data EEPROM
int ReadEE(unsigned int addr)
{
  // Set up a pointer to the EEPROM location to be write.
  TBLPAG = 0x7F;              // Table Page Register
 
  WREG0 = addr;               // address to write data			
  __asm__("TBLRDL	[W0],W4");  // read data

  return (WREG4);
}

//----------------------------------------------------:Main
int main(void) 
{  
  int EE_DATA;
	
	WriteWordEE(0xFC00,0xABCD);   // Writing data:0x0A0A, Address:0xFC00
	EE_DATA = ReadEE(0xFC00);     // Reading data at address 0xFC00

  while (1)                     // loop forever
    ;	
									
    return 0;
}
