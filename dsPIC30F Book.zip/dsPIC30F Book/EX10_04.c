/*
 * File      : EX10_04.c
 * Purpose   : Erasing&Writing Row FLASH Programming
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 17/11/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);       // Sw Disabled, Mon Disabled, XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Code Protect Disabled


//----------------------------------------------------:Global Variables
  unsigned int datLW[16]= {0x1001,0x2002,0x3003,0x4004,0x5005,0x6006,0x7007,0x8008,                    
                           0x9009,0xA00A,0xB00B,0xC00C,0xD00D,0xE00E,0xF00F,0x1234};
  unsigned char datH[16]= {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,                    
                           0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF};


//----------------------------------------------------:delay_ms
// Delay 1 ms (XT w/PLL 1x)
void delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
  for (i=0; i<182; i++)
    Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:RTSP_ProgramFLASH
// RTSP Program operations
void RTSP_ProgramFLASH(void)
{
  NVMKEY = 0x55;    // Write the KEY sequence
  NVMKEY = 0xAA;          
  _WR = 1;          // Start the erase cycle
  while (_WR)       // wait for erase cycle is complete
    ;  
}  

//----------------------------------------------------:EraseRowFLASH
void EraseRowFLASH(unsigned int addr)
{
  // Setup NVMCON to erase one row of Flash program memory
  NVMCON = 0x4041;        // Erase one row

  // Set up a pointer to the row to be erased.
  TBLPAG = 0x00;          // Table Page Register
  NVMADR = addr;          // NVM Address bits <15:0>  

  RTSP_ProgramFLASH();    // Write the KEY sequence
}

//----------------------------------------------------:WriteDataFLASH
int WriteDataFLASH(unsigned int addr)
{
  int i;          

  // Setup NVMCON to write multiple words of Flash program memory
  NVMCON = 0x4001;      // Erase one row

  // Set up a pointer to first program memory location to be written.
  TBLPAG = 0x00;        // Table Page Register
  
  // Load program memory write latches
  for (i=0; i<16; i++) {
    WREG2 = datLW[i];   // low word data
    WREG3 = datH[i];    // high byte data
    WREG0 = addr;       // program address
    __asm__("TBLWTL	W2,[W0]");      // write data		
    __asm__("TBLWTH	W3,[W0++]");    // write data		
    addr += 2;
  }

  RTSP_ProgramFLASH();  // Write the KEY sequence
}

//----------------------------------------------------:ReadDataFLASH
long ReadDataFLASH(unsigned int addr)
{
  long lFlash;
  
  // Set up a pointer to first program memory location.
  TBLPAG = 0x00;        // Table Page Register
  WREG1 = addr;         // program address
    
  __asm__("TBLRDL	[W1],W10");    // read data low
  __asm__("TBLRDH	[W1++],W11");    // read data high	
    
  lFlash = WREG11;
  lFlash = (lFlash<<16)| WREG10;
  
  return (lFlash);  
} 
 
//----------------------------------------------------:Main
int main(void) 
{
  long datFlash;

  WriteDataFLASH(0x02A0); // Writing a Row of Program Memory
  delay_ms(5);            // delay 10 ms
  EraseRowFLASH(0x02A0);  // Erasing a Row of Program Memory
  delay_ms(5);            // delay 10 ms
  WriteDataFLASH(0x02C8); // Writing a Row of Program Memory
    
  datFlash = ReadDataFLASH(0x02D0); // Read..
  
  while (1)   // loop nothing
    ;	
									
  return 0;
}

