/*
 * File      : EX11_01.c
 * Purpose   : 74HC595 I/O expander for SPI bus
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 16/03/09
 * Ref.      :  
*/

//----------------------------------------------------:Note
// dsPIC30F     74HC595  
// SDI1/RF2 ->  SH_CP pin
// SDO1/RF3 ->  DS pin
// SCK1/RE8 ->  ST_CP pin
// SS1/RB2  ->  Not use

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC

#define _SPI_V1                 // SPI V1
#include "spi.h"


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);       // Sw Disabled, Mon Disabled, XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Coode Protect off


//----------------------------------------------------:Define PIN 74HC595
#define ST_CP_PIN    _LATF2      // SH_CP pin(11) 


//----------------------------------------------------:delay_ms
// Delay 1 ms (XT w/PLL 1x)
static void Delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
  for (i=0; i<182; i++) {
    Nop();              // delay 1 mch cycle
  }  
}

//----------------------------------------------------:SPI_MasterInit
void SPI_MasterInit(void)
{
  _TRISF3 = 0;    // Set SPI pin for output  
  _TRISE8 = 0;    
    
  CloseSPI1();    // CloseSPI. Disables SPI module

  // OpenSPI 
  OpenSPI1( // SPIxCON reg.	
            FRAME_ENABLE_OFF &    // Frame SPI support Disable 
            FRAME_SYNC_OUTPUT &   // Frame sync pulse Output (master)
            ENABLE_SDO_PIN &      // SDO pin is used by module
            SPI_MODE16_OFF &		  // Communication is byte wide (use 8 bit data mode) 
            SPI_SMP_OFF &         // Input data sampled at middle of data output time
            SPI_CKE_OFF &         // Transmit happens on transition from
                                  // idle clock state to active clock state
            SLAVE_ENABLE_OFF &		// Slave Select not used by module            
            CLK_POL_ACTIVE_LOW &  // (CKP) Idle state for clock is high, active is low
            MASTER_ENABLE_ON &		// Master Mode
            SEC_PRESCAL_8_1 &			// Secondary Prescale 8:1
            PRI_PRESCAL_64_1,			// Primary Prescale 64:1            
            // SPIxSTAT Reg.
            SPI_ENABLE &          // Enable SPI module
            SPI_IDLE_CON &        // SPI working on Idle mode
            SPI_RX_OVFLOW_CLR     // Automatic clear receive overflow flag
            );

  DisableIntSPI1;                 // Macros to Disable interrupts of SPI1  
}

//----------------------------------------------------:SPI_Write
// SPI Write
void SPI_Write(unsigned char cData)
{   
  // Start transmission
  putcSPI1(cData);
  // Wait for transmission complete
  while (SPI1STATbits.SPITBF);  
  
  ST_CP_PIN = 1;  // Latch pulse
  ST_CP_PIN = 0;
}

//----------------------------------------------------:Main
int main(void) 
{      
  _TRISF2 = 0;	          // Set ST_CP pin for output
  
  SPI_MasterInit();       // Initialize SPI    
  SPI_Write(0xFF);        // Clear data
  
  while (1) {             // loop forever
    SPI_Write(0xAA);
    Delay_ms(1000);
    SPI_Write(0x55);
    Delay_ms(1000);    
  }
									
  return 0;
}

