/*
 * File      : EX11_01.c
 * Purpose   : GLCD5110
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 05/06/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>     // generic header file for dsPIC


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL16); // Sw Disabled, Mon Disabled, XT w/PLL 16
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Coode Protect off


//----------------------------------------------------:Library
#include "LIB_GLCD5110.C"        // GLCD5110 Module Library


//----------------------------------------------------:Main
int main(void) 
{
  GLCD5110_Init();    // Initialize GLCD5110

  GLCD5110_GotoXY(7,1);
  GLCD5110_PutStr("NOKIA LCD 5110");
  GLCD5110_GotoXY(10,3);
  GLCD5110_PutStr("Graphic LCD");

  while (1)           // loop nothing
    ;  
									
  return 0;
}

