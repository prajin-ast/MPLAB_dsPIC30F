/*
 * File      : EX12_01.c
 * Purpose   : I2C Module (PCF8574A)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 11/03/09
 * Ref.      :  
*/

//----------------------------------------------------:Note
// dsPIC30F     PCF8574A
// RF2/SDA ->	  pin 15 (SDA)
// RF3/SCL ->	  pin 14 (SCL)

//----------------------------------------------------:Includes
#include <p30fxxxx.h>		  // generic header file for dsPIC
#include "i2c.h"          // use I2C Module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);			      // Code Protect Disabled


//----------------------------------------------------:Defines
#define TRUE             1
#define PCF8574A_ID      0x70      // 0111[000]0,PCF8574A Slave Address(bit1-3)


//----------------------------------------------------:MI2C ISR
// MI2C Interrupt
void _ISR _MI2CInterrupt(void)
{
  // Nothing...
  _MI2CIF = 0;    // clear Master I2C interrupt flag
}

//----------------------------------------------------:Delay ms
// Delay 1 ms (XT w/PLL 4x)
void Delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Init_MI2C
// Initialize Master I2C
void Init_MI2C(void)
{
  unsigned int config2, config1;

  _TRISF2 = 1;                // Enable SDA
  _TRISF3 = 1;                // Enable SCL

  // configure I2C for 7 bit address mode
  config1 =(I2C_ON &          // I2C module enabled
            I2C_IDLE_CON &    // continue I2C module in Idle mode
            I2C_CLK_HLD	&     // hold clock
            I2C_IPMI_DIS &    // IPMI mode not enabled
            I2C_7BIT_ADD&     // I2CADD is 7-bit address
            I2C_SLW_DIS &     // Disable Slew Rate Control for 100KHz
            I2C_SM_DIS &      // Disable SM bus specification
            I2C_GCALL_DIS &   // Disable General call address
            I2C_STR_DIS &     // disable clock stretching
            I2C_ACK &         // Transmit 0 to send ACK as acknowledge
            I2C_ACK_DIS &     // Acknowledge condition Idle
            I2C_RCV_DIS &     // Receive sequence not in progress
            I2C_STOP_DIS &    // Stop condition Idle
            I2C_RESTART_DIS & // Start condition Idle
            I2C_START_DIS);   // Start condition Idle

  config2 = 40;               // Configuration i2c baudrate at 100 kHz

  OpenI2C(config1,config2);   // Execute configuration module i2c
  EnableIntMI2C;              // Enable interrupt module i2c  in master mode
}

//----------------------------------------------------:Write PCF8574A
void Write_PCF8574A(unsigned char dat)
{
  StartI2C();                   // Start i2c condition
  while(_SEN);                  // Wait until start OK

  MasterWriteI2C(PCF8574A_ID);  // Send ID into PCF8574A - write
  IdleI2C();                    // Wait condition until I2C bus is Idle
  MasterWriteI2C(dat);          // Send data
  IdleI2C();                    // Wait condition until I2C bus is Idle

  StopI2C();                    // Stop i2c condition
  while (_PEN);                 // Wait until stop OK
}

//----------------------------------------------------:Read PCF8574A
unsigned char Read_PCF8574A(void)
{
  unsigned char indata;

  StartI2C();                    // Start i2c condition
  while (_SEN);                  // Wait until start OK
  
  MasterWriteI2C(PCF8574A_ID+1); // Send ID into PCF8574A - read
  IdleI2C();                     // Wait condition until I2C bus is Idle
  indata = MasterReadI2C();      // Read data 8 byte from PCF8574A
  IdleI2C();                     // Wait condition until I2C bus is Idle
  
  StopI2C();                     // Stop i2c condition
  while (_PEN);                  // Wait until stop OK

  return(indata);
}

//----------------------------------------------------:Main
int main(void)
{
  unsigned char i=0, iData;

  Init_MI2C();        // Initialize Master I2C

  while (i++<10) {    // Toggle LED
    Write_PCF8574A(0x0F);
    Delay_ms(100);
    Write_PCF8574A(0x00);
    Delay_ms(100);
  }

  while (TRUE) {
    iData = Read_PCF8574A();  // Read data
    iData = iData>>4;         // Shift to Nibble Low
    iData = iData|0xF0;       // Mark bit Nibble High
    Write_PCF8574A(iData);    // Out data
  }
  return 0;
  
}

