/*
 * File      : EX12_02.c
 * Purpose   : I2C Module (24LC128)
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 11/03/09
 * Ref.      :  
*/

//----------------------------------------------------:Note
// dsPIC30F     24LC128
// RF2/SDA ->	  pin 5 (SDA)
// RF3/SCL ->	  pin 6 (SCL)

//----------------------------------------------------:Includes
#include <p30fxxxx.h>		  // generic header file for dsPIC
#include "i2c.h"          // use I2C Module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);			      // Code Protect Disabled


//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library


//----------------------------------------------------:Defines
#define TRUE          1
#define ID_24LCxxx    0xA0      // Address 24LCxx Serial EEPROM


//----------------------------------------------------:MI2C ISR
// MI2C Interrupt
void _ISR _MI2CInterrupt(void)
{
  // Nothing...
  _MI2CIF = 0;    // clear Master I2C interrupt flag
}

//----------------------------------------------------:Delay ms
// Delay 1 ms (XT w/PLL 4x)
void Delay_ms(unsigned int ms)
{
  unsigned int i;

  for (; ms>0; ms--)
    for (i=0; i<728; i++)
      Nop();                // delay 1 mch cycle
}

//----------------------------------------------------:Init_MI2C
// Initialize Master I2C
void Init_MI2C(void)
{
  unsigned int config2, config1;

  _TRISF2 = 1;                // Enable SDA
  _TRISF3 = 1;                // Enable SCL

  // configure I2C for 7 bit address mode
  config1 =(I2C_ON &          // I2C module enabled
            I2C_IDLE_CON &    // continue I2C module in Idle mode
            I2C_CLK_HLD	&     // hold clock
            I2C_IPMI_DIS &    // IPMI mode not enabled
            I2C_7BIT_ADD&     // I2CADD is 7-bit address
            I2C_SLW_DIS &     // Disable Slew Rate Control for 100KHz
            I2C_SM_DIS &      // Disable SM bus specification
            I2C_GCALL_DIS &   // Disable General call address
            I2C_STR_DIS &     // disable clock stretching
            I2C_ACK &         // Transmit 0 to send ACK as acknowledge
            I2C_ACK_DIS &     // Acknowledge condition Idle
            I2C_RCV_DIS &     // Receive sequence not in progress
            I2C_STOP_DIS &    // Stop condition Idle
            I2C_RESTART_DIS & // Restart condition Idle
            I2C_START_DIS);   // Start condition Idle
            
  config2 = 40;               // Configuration i2c baudrate at 100 kHz

  OpenI2C(config1,config2);   // Execute configuration module I2C
  EnableIntMI2C;              // Enable interrupt module I2C  in master mode
}

//----------------------------------------------------:Write 24LCxxx
void Write_24LCxxx(unsigned int adr,unsigned char dat)
{  
  StartI2C();                   // Start I2C condition
  while(_SEN);                  // Wait until start OK

  MasterWriteI2C(ID_24LCxxx);   // Send ID into 24LCxxx - write
  IdleI2C();                    // Wait condition until I2C bus is Idle
  MasterWriteI2C(adr>>8);       // Address High Byte
  IdleI2C();                    
  MasterWriteI2C(adr);          // Address Low Byte
  IdleI2C();                    
  MasterWriteI2C(dat);          // send data
  IdleI2C();                    
    
  StopI2C();                    // Stop i2c condition
  while (_PEN);                 // Wait until stop OK  
}

//----------------------------------------------------:Read 24LCxxx
unsigned char Read_24LCxxx(unsigned int adr)
{
  unsigned char dat;

  StartI2C();                   // Start i2c condition
  while (_SEN);                 // Wait until start OK
  
  MasterWriteI2C(ID_24LCxxx);   // Send ID into 24LCxxx - write
  IdleI2C();                    // Wait condition until I2C bus is Idle
  MasterWriteI2C(adr>>8);       // Address High Byte
  IdleI2C();                    
  MasterWriteI2C(adr);          // Address Low Byte
  IdleI2C();                    

  RestartI2C();                 // Start i2c condition
  while (_RSEN);                // Wait until start OK
  
  MasterWriteI2C(ID_24LCxxx+1); // Send ID into 24LCxxx - read  
  IdleI2C();                    
  dat = MasterReadI2C();        // Read data 8 byte from 24LCxxx
  IdleI2C();                    
    
  StopI2C();                    // Stop I2C condition
  while (_PEN);                 // Wait until stop OK

  return(dat);                  // return data  
}

//----------------------------------------------------:Main
int main(void)
{
	unsigned int ee_adr;
	unsigned char dat=1;
	char buf[30];

  Uart1Init(0);     // Initialize UART1
  Init_MI2C();      // Initialize Master I2C

	Uart1PrintStr("\f24LCxx Serial EEPROM Write/Read");

	for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
    Write_24LCxxx(ee_adr,dat++);  // Write data
		Delay_ms(6);  // Wait for write-cycle time
	}
	Uart1PrintStr("\n\rWrite EEPROM Addr:0-F with 1-16 Complete...");
	
	Uart1PrintStr("\n\rRead EEPROM Now...");
	for (ee_adr=0x0000; ee_adr<=0x000F; ee_adr++) {
    sprintf(buf,"\n\rRead EEPROM @%X data: %d",
            ee_adr,Read_24LCxxx(ee_adr)); // Read data
    Uart1PrintStr(buf);
	}

	while (1);			// Loop Nothing

  return 0;
  
}
