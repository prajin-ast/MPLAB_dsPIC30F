/*
 * File      : EX13_02.c
 * Purpose   : Motor Control PWM
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 02/06/09
 * Ref.      :  
*/

//----------------------------------------------------:Note
// PWM1: PWM1L/RE0, PWM1H/RE1
// PWM2: PWM2L/RE2, PWM2H/RE3
// PWM3: PWM3L/RE4, PWM3H/RE5
// FLTA/RE8

//----------------------------------------------------:Includes
#include <p30fxxxx.h>   // generic header file for dsPIC
#include <pwm.h>        // use MCPWM Module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);  // Sw Disabled, Mon Disabled,XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:MCPWM ISR
// MCPWM Interrupt
void _ISR _PWMInterrupt(void)
{
  _PWMIF = 0;   // clear MCPWM interrupt flag
}

//----------------------------------------------------:FaultA ISR
// FaultA Interrupt
void _ISR _FLTAInterrupt(void)
{  
  _FLTAIF = 0;  // clear FaultA interrupt flag
}

//----------------------------------------------------:Init_MCPWM
// Initialize MCPWM
void Init_MCPWM(void)
{
  unsigned int config, period, sptime;
  unsigned int config1, config2, config3;
  unsigned int dutycyclereg, dutycycle, updatedisable;

  // Configure pwm interrupt enable/disable and set interrupt priorties
  config = (PWM_INT_EN &        // Enable PWM interrupt
            PWM_FLTA_EN_INT &   // Enable Fault A Interrupt
            PWM_INT_PR1 &       // period interrupt priority 1
            PWM_FLTA_INT_PR0);  // FaultA interrupt priority 0

  ConfigIntMCPWM(config);
  
  SetMCPWMFaultA(PWM_OVA1H_INACTIVE &   // The PWM output pin is driven INACTIVE 
                 //PWM_OVA1H_ACTIVE &     // The PWM output pin is driven ACTIVE 
                 PWM_FLTA_MODE_LATCH &  // The Fault A input pin latches                  
                 PWM_FLTA1_EN           // PWM1H/PWM1L pin pair is controlled by Fault Input A. 
                );

  period = 11519;               // Set to PTPER register
  sptime = 0x0;                 // Set to SEVTCMP register
  config1	= (PWM_EN &           // Module enable
             PWM_OP_SCALE1 &    // Out put post scaler 1:1
             PWM_IPCLK_SCALE16 &  // Input pre scaler 1:16
             PWM_MOD_FREE       // Mode of operation Free Running
            );

  config2 = (PWM_MOD1_IND &     // 1th channel in independant mode
             PWM_PDIS3H &       // H of channel 3 works as IO
             PWM_PDIS2H &       // H of channel 2 works as IO
             PWM_PEN1H &        // H of channel 1 works as PWM
             PWM_PDIS3L &       // L of channel 2 works as IO
             PWM_PDIS2L &       // L of channel 2 works as IO
             PWM_PDIS1L         // L of channel 1 works as IO               
             );
   
  config3 = (PWM_SEVOPS1 &      // Special event post scaler 1:1
             PWM_OSYNC_PWM &    // over ride syncronised with PWM clk
             PWM_UEN            // Update of PDCs and PTPER enabled 
            );
	
  OpenMCPWM(period, sptime, config1, config2, config3);

  // Configre PWM to generate square wave of 100% duty cycle
  dutycyclereg = 1;       // duty cycle register (PDC1)
  dutycycle = 11519<<1;   // Assign dutycycle to PDC1<15:1>
  updatedisable = 0;      // update enable

  SetDCMCPWM(dutycyclereg, dutycycle, updatedisable);
}

//----------------------------------------------------:Main
int main(void)
{
  int dutycycle, per_duty;

  Init_MCPWM();     // Initialize MCPWM
  TRISB = 0;        // Port B output    
  _TRISE2 = 1;      // Port RE2,3,4,5 input
  _TRISE3 = 1;
  _TRISE4 = 1;
  _TRISE5 = 1;
  _TRISE8 = 1;

  per_duty = 100;   // 100%
  _LATB0 = 0;       // Start motor
  _LATB1 = 1;       

  while (1) {
    if (_RE2 == 0) {
      _LATB0 = 0;   // output low
      _LATB1 = 1;   // output high
    }
    if (_RE3 == 0) {
      _LATB0 = 1;   // output high
      _LATB1 = 0;   // output low
    }
    if (_RE4 == 0) {
      _LATB0 = 0;   // output low
      _LATB1 = 0;   // output low
      SetDCMCPWM(1, (11519<<1), 0);  // Set duty to 100%
    }
    if (_RE5 == 0) {
      if (per_duty-- < 0) {
        per_duty = 100;
      }
      dutycycle = (per_duty*115);
      SetDCMCPWM(1, (dutycycle<<1), 0);
      while(!_RE5);   // wait for up
    }     
  }

  return 0;
}
