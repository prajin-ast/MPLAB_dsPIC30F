/*
 * File      : EX14_01.c
 * Purpose   : QEI Module
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 09/06/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>   // generic header file for dsPIC
#include <qei.h>        // QEI Module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Library
#include "LIB_Uart1.C"          // UART1 Module Library
char buf[30];


//----------------------------------------------------:QEI ISR
// QEI Interrupt Service Routine
void _ISR _QEIInterrupt(void)
{
  sprintf(buf,"\r** QEI ISR (Count: %u) **",POSCNT);
  putsUART1(buf);  // Sent new line & return to UART TX
  _QEIIF = 0;     // Clear QEI interrupt flag
}

//----------------------------------------------------:Init_QEI
// Initialize QEI
void Init_QEI(void)
{
  // Enable QEI Interrupt and Priority to "1"
  ConfigIntQEI(QEI_INT_PRI_1 &     // Setting the priority 1 
               QEI_INT_ENABLE      // Set the Interrupt enable bit
              );

  OpenQEI(QEI_DIR_SEL_CNTRL &       // Control/Status Bit, QEICON<11>, Defines Timer Counter (POSCNT) Direction  
          QEI_INT_CLK &             // Internal clock (FOSC/4)
          QEI_INDEX_RESET_DISABLE & // Index Pulse does not reset Position Counter
          QEI_CLK_PRESCALE_256 &    // QEI 1:256 prescale value
          QEI_GATED_ACC_DISABLE &   // QEI Timer gated time accumulation enabled
          QEI_LOGIC_CONTROL_IO &    // QEI logic controls state of I/O pin
          QEI_INPUTS_NOSWAP &       // QEI Phase A and Phase B inputs not swapped
          QEI_MODE_x4_MATCH &       // x4 mode with position counter reset by match (MAXCNT)
          QEI_IDLE_CON,             // QEI Discontinue module operation when device enters a idle mode.
          0                         // configures the Digital Filters (DFLTCON)
         );

  POSCNT = 0;                      // Set Position Counter Register
  MAXCNT = 0xFFFF;                 // Set Maximum Count Register
}

//----------------------------------------------------:Main
int main(void)
{
  unsigned int pos=1;
  char updn;

  _TRISE0 = 1;    // Set RE0,RE1 input 
  _TRISE1 = 1;
  _TRISE2 = 0;    // Set RE2,RE3 output
  _TRISE3 = 0;
  
  _LATE2 = 0;     // RE2/RE3 OFF
  _LATE3 = 0;
  
  ADPCFG = 0xFF;  // Set PORTB Digital input
  Init_QEI();     // Initialize QEI
  Uart1Init(0);   // Initialize the UART1, Interrupt OFF

  while (1) {
    if (_RE0 == 0) 
      pos = 1;    // Forward Travel
    else if (_RE1 == 0) 
      pos = 0;    // Reverse Travel

    if (pos) {
      _LATE2 = 0; _LATE3 = 1;
      _LATE2 = 0; _LATE3 = 0;
      _LATE2 = 1; _LATE3 = 0;
      _LATE2 = 1; _LATE3 = 1;
    } else {
      _LATE2 = 1; _LATE3 = 1;
      _LATE2 = 1; _LATE3 = 0;
      _LATE2 = 0; _LATE3 = 0;
      _LATE2 = 0; _LATE3 = 1;
    }

    if (QEICONbits.UPDN)  // Position Counter Direction Status
      updn = '+';
    else 
      updn = '-';
      
    sprintf(buf,"\rDirection %c Count %u",updn, ReadQEI());
    putsUART1(buf);

  } 
  return 0;
}

