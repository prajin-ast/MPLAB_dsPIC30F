/*
 * File      : EX14_02.c
 * Purpose   : QEI Module
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 09/06/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>   // generic header file for dsPIC
#include <qei.h>        // QEI Module


//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Library
#include "LIB_LCD16x2.c"          // LCD16x2 Module Library
char buf[30];


//----------------------------------------------------:QEI ISR
// QEI Interrupt Service Routine
void _ISR _QEIInterrupt(void)
{
  _QEIIF = 0;     // Clear QEI interrupt flag
}

//----------------------------------------------------:Init_QEI
// Initialize QEI
void Init_QEI(void)
{
  // Enable QEI Interrupt and Priority to "1"
  ConfigIntQEI(QEI_INT_PRI_1 &     // Setting the priority 1 
               QEI_INT_ENABLE      // Set the Interrupt enable bit
              );

  OpenQEI(QEI_DIR_SEL_CNTRL &       // Control/Status Bit, QEICON<11>, Defines Timer Counter (POSCNT) Direction  
          QEI_INT_CLK &             // Internal clock (FOSC/4)
          QEI_INDEX_RESET_DISABLE & // Index Pulse does not reset Position Counter
          QEI_CLK_PRESCALE_256 &    // QEI 1:256 prescale value
          QEI_GATED_ACC_DISABLE &   // QEI Timer gated time accumulation enabled
          QEI_LOGIC_CONTROL_IO &    // QEI logic controls state of I/O pin
          QEI_INPUTS_NOSWAP &       // QEI Phase A and Phase B inputs not swapped
          QEI_MODE_x4_MATCH &       // x4 mode with position counter reset by match (MAXCNT)
          QEI_IDLE_CON,             // QEI Discontinue module operation when device enters a idle mode.
          0                         // configures the Digital Filters (DFLTCON)
         );

  POSCNT = 0;                      // Set Position Counter Register
  MAXCNT = 0xFFFF;                 // Set Maximum Count Register
}

//----------------------------------------------------:Main
int main(void)
{
  ADPCFG = 0xFF;  // Set PORTB Digital input
  Init_QEI();     // Initialize QEI
  LCDInit();      // Initialize LCD16x2

  LCDPrintxy(1,2, 0, "Count : ");

  while (1) {
    if (QEICONbits.UPDN)  // Position Counter Direction Status
      LCDPrintxy(1,1, 0, "Forward Travel");
    else 
      LCDPrintxy(1,1, 0, "Reverse Travel");
    
    sprintf(buf,"%u",ReadQEI());
    LCDPrintxy(8,2, 0, "         ");
    LCDPrintxy(8,2, 0, buf);
  }
  return 0;
}

