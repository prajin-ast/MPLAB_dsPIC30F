/*
 * File      : EX15_01.c
 * Purpose   : Vecter Function Examples
						   DSP Library 
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 05/06/09
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>   // generic header file for dsPIC
#include "dsp.h"        // DSP Library

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT);  // Sw Disabled, Mon Disabled, XT w/PLL 1x
_FWDT(WDT_OFF);                 // Watchdog timer off


//----------------------------------------------------:Note
//extern fractional* VectorAdd (		/* Vector addition */
//					 dstV[elem] =	srcV1[elem] + srcV2[elem] 
//					 (in place capable) 
//					 (with itself capable) 
//   int numElems,          /* number elements in srcV[1,2] (N) */
//   fractional* dstV,      /* ptr to destination vector */
//   fractional* srcV1,     /* ptr to source vector one */
//   fractional* srcV2      /* ptr to source vector two */
//                          /* dstV returned */
//);

#define numElems 3          // elements vector

int dstV[numElems];
int srcV1[numElems] = {2, 3, -4};
int srcV2[numElems] = {1, -5, 8};

//----------------------------------------------------:Main
int main(void) 
{ 
  VectorAdd(numElems,dstV,srcV1,srcV2);    // Vector addition

  while(1)
    ;

  return 0;
}
