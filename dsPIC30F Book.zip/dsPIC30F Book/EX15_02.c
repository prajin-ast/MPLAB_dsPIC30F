/*
 * File      : EX15_02.c
 * Purpose   : Matrix Function Examples
               DSP Library 
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 05/06/09
 * Ref.      :  
*/

//----------------------------------------------------:
#include <p30fxxxx.h>           // generic header file for dsPIC
#include "dsp.h"        // DSP Library

//----------------------------------------------------:Config fuses
_FOSC(CSW_FSCM_OFF & XT_PLL4);  // Sw Disabled, Mon Disabled, XT w/PLL 4x
_FWDT(WDT_OFF);                 // Watchdog timer off
_FGS(CODE_PROT_OFF);            // Code Protect Disabled	


//----------------------------------------------------:Note
//extern fractional* MatrixAdd (		/* Matrix addition */
//					 dstM[i][j] = srcM1[i][j] + srcM2[i][j]
//					 (in place capable) 
//					 (with itself capable) 
//   int numRows,           /* number rows in srcM[1,2] (R) */
//   int numCols,           /* number columns in srcM[1,2] (C) */
//   fractional* dstM,      /* ptr to destination matrix */
//   fractional* srcM1,     /* ptr to source one matrix */
//   fractional* srcM2      /* ptr to source two matrix */
//	 /* dstM returned */
// );

#define numRows 		2       // Rows Matrix
#define numCols 		3       // Columns Matrix
typedef fractional*	fract;

int dsM[numRows][numCols];
int srcM1[numRows][numCols] = {{1,-2,3},{0,4,5}};
int srcM2[numRows][numCols] = {{3,0,-6},{2,-3,1}};


//----------------------------------------------------:Main
int main(void) 
{
    // Matrix addition
    MatrixAdd(numRows,numCols,(fract)dsM,(fract)srcM1,(fract)srcM2);
  
    while (1)
    ;

    return 0;
}
