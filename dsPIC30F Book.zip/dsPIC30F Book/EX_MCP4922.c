//-----------------------------------------------:
// File     : EX_MCP4922.c
// Purpose  : MSSP (SPI Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C30 Compiler
// Target   : dsPIC30F2010
//-----------------------------------------------:

//-----------------------------------------------:Note
// dsPIC30F2010 -> MCP4922
// RF3/SDO1     -> SDI
// RE8/SCK1     -> SCK
// RB2/SS1      -> CS
// GND          -> LDAC
// +5V          -> SHDN

//-----------------------------------------------:Includes
#include <p30fxxxx.h>		               // generic header file for dsPIC
#include <spi.h>                       // use spi module

//-----------------------------------------------:Setting configuration fuses
_FOSC(CSW_FSCM_OFF & XT_PLL16);	      // Sw Disabled, Mon Disabled, XT w/PLL 16x
_FWDT(WDT_OFF);                       // Watchdog timer off
_FGS(CODE_PROT_OFF);                  // Code Protect Disabled

//-----------------------------------------------:Defines
#define CFG_DACA   0x3000  //0b0011 000000000000 
#define CFG_DACB   0xB000  //0b1011 000000000000

#define SET_SDO     TRISFbits.TRISF3
#define SET_SCK     TRISEbits.TRISE8
#define SET_CS      TRISBbits.TRISB2
#define DAC_CS      LATBbits.LATB2
#define DAC_SCK     LATEbits.LATE8

//-----------------------------------------------:Delay ms
void delay_ms(unsigned int ms)
{
  unsigned int i;
  
  for(; ms>0; ms--)
  for(i=0; i<816; i++)
    Nop();
}

//-----------------------------------------------:Init SPI1
void Init_SPI1(void)
{
  SET_SDO = 0;      // Set RF3 output
  SET_SCK = 0;      // Set RE8 output
  SET_CS = 0;       // Set RB2 output
  
  DAC_SCK = 1;
  DAC_CS = 0;
    
  CloseSPI1();      // CloseSPI. Disables SPI module
  // OpenSPI mode 0,0
  OpenSPI1(FRAME_ENABLE_OFF &   // Frame SPI support Disable
           FRAME_SYNC_OUTPUT &  // Frame sync pulse Output (master)
           ENABLE_SDO_PIN &     // SDO pin is  used by module
           SPI_MODE16_ON &      // Communication is word wide  
           SPI_SMP_OFF &        // Input data sampled at middle of data output time
           SLAVE_ENABLE_OFF &   // Slave Select not used by module
           
           SPI_CKE_ON &         // Transmit happens from active clock state to idle clock state
           CLK_POL_ACTIVE_HIGH &  // Idle state for clock is low, active is high
           
           MASTER_ENABLE_ON &   // Master Mode
           SEC_PRESCAL_4_1 &    // Secondary Prescale 4:1 
           PRI_PRESCAL_16_1,    // Primary Prescale 16:1  
           SPI_ENABLE &         // Enable modul
           SPI_IDLE_CON &       // Continue module operation in idle mode
           SPI_RX_OVFLOW_CLR);  // Clear receive overflow bit.       

  DisableIntSPI1;      // Macros to Disable interrupts of SPI1
}

//-----------------------------------------------:Write DAC
void write_dac(unsigned int data)
{ 
  DAC_CS = 0;         // Enable function
  Nop();
  WriteSPI1(data);    // Write 16-bit words
  while(SPI1STATbits.SPITBF);  // Wait until data success
  Nop(); Nop();
  DAC_CS = 1;         // Disable function
  Nop();
  DAC_CS = 0;         // Enable function
}

//-----------------------------------------------:Main
int main(void)
{
  unsigned int dac = 0;

  Init_SPI1();    // Initialize SPI1

  while (1)       // Loop forever
  {
    write_dac(CFG_DACA|dac);  // Write Vouta
    dac = dac + 100;
    if (dac >= 4095) dac = 0;
    delay_ms(500);
  }
  return 0;
}

