/*
Author		:	prajin palangsantikul
Company		:	appsofttech co.,ltd.
Filename	:	LIB_ADC10.c
Purpose		:	ADC10 Library
Date		  :	10/03/2009
*/

//----------------------------------------------------:Includes
#include <adc10.h>          // 10bit ADC module library functions

//----------------------------------------------------:Initialize ADC 10bit
void ADC10Init(void)
{
  unsigned int config1, config2, config3;
  unsigned int configport, configscan;
  unsigned int channel;
  
  CloseADC10();   // Turn off A/D
  
  // Configure ADCON1 register
  config1 = ADC_MODULE_OFF &          // A/D Converter off
            ADC_IDLE_CONTINUE &       // A/D Operate in Idle mode
            ADC_FORMAT_INTG &         // A/D data format integer
            ADC_CLK_AUTO &            // sampling/conversion (Auto convert)
            ADC_SAMPLE_SIMULTANEOUS & // Simultaneous sampling
            ADC_AUTO_SAMPLING_ON &    // Auto sampling Select
            ADC_SAMP_ON;              // sample/hold amplifiers are sampling
            
  // Configure ADCON2 register
  config2 = ADC_VREF_AVDD_AVSS &    // Vref+ is AVdd and Vref- is AVss
            ADC_SCAN_OFF &          // Do notScan Input
            ADC_CONVERT_CH_0ABC &   // A/D channels utilised
            ADC_SAMPLES_PER_INT_4 & // interrupt at 4th sample
            ADC_ALT_BUF_OFF &       // Buffer 16-word buffer
            ADC_ALT_INPUT_OFF;      // use MUXA only
            
  // Configure ADCON2 register
  config3 = ADC_SAMPLE_TIME_3 &     // A/D Auto Sample Time 3 Tad
            ADC_CONV_CLK_SYSTEM &   // Clock Source Clock derived from system clock
            ADC_CONV_CLK_3Tcy2;     // A/D Conversion Clock Select bits
  
  // Configure ADCHS register
  channel = ADC_CH0_POS_SAMPLEA_AN3 &       // A/D Chan 0 pos i/p sel for SAMPLE A is AN3
            ADC_CH0_NEG_SAMPLEA_NVREF &     // A/D Chan 0 neg i/p sel for SAMPLE A is -Vref
            ADC_CHX_POS_SAMPLEA_AN0AN1AN2 & // A/D Chan A B C pos i/p sel for SAMPLE A are AN0, 1 and 2
            ADC_CHX_NEG_SAMPLEA_NVREF;      // A/D CHA, CHB, CHC neg input is VREF-

  // RB0, RB1, RB2 & RB3 = analog
  configport = 0xFFF0;  // ADPCFG register
  
  // Configure ADCSSL register
  configscan = SCAN_NONE;             // Skip AN0-AN15 for Input Scan
    
  // configures the ADC
  OpenADC10(config1, config2, config3, configport, configscan);
  // sets the positive and negative inputs for the sample multiplexers            
  SetChanADC10(channel);
}

