/*
Author    : prajin palangsantikul                     
Company   : appsofttech co.,ltd.                      
Filename  :	LIB_EEPROM.C
Purpose   : Write&Erase 1 data word of data EEPROM Memory
Ref..     :	-
Date      :	25/11/2008
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC

//----------------------------------------------------:Prototype Function
void RTSP_ProgramErase(unsigned int cmd);
void EraseWordEE(unsigned int addr);
void WriteWordEE(unsigned int addr, unsigned int dat);

//----------------------------------------------------:RTSP_ProgramErase
// RTSP Program and Erase operations
void RTSP_ProgramErase(unsigned int cmd)
{
  // NVMCON Reg. Values for RTSP Program and Erase Operations
  NVMCON = cmd;     // Command NVMCON value
  NVMKEY = 0x55;    // Write the KEY sequence
  NVMKEY = 0xAA;    
  _WR = 1;          // Start the erase cycle
  while (_WR)       // wait for erase cycle is complete
    ;  
}  

//----------------------------------------------------:EraseWordEE
// Erase one word eeprom
void EraseWordEE(unsigned int addr)
{
  // Set up a pointer to the EEPROM location to be erased.
  NVMADR = addr;              // NVM Address bits <15:0>
  TBLPAG = 0x7F;              // Table Page Register
  
  // Setup NVMCON to erase 1 data word of EEPROM  
  RTSP_ProgramErase(0x4044);
}

//----------------------------------------------------:WriteWordEE
// Write one word eeprom
void WriteWordEE(unsigned int addr, unsigned int dat)
{
  // Set up a pointer to the EEPROM location to be write.
  TBLPAG = 0x7F;              // Table Page Register  
  
  WREG1 = dat;                // data
  WREG0 = addr;               // address to write data  
  __asm__("TBLWTL	W1,[W0]");  // write data

  // Setup NVMCON to write 1 data word of EEPROM  
  RTSP_ProgramErase(0x4004);
}

