/*
 * File      : EX05_04_Time_LIB.c
 * Purpose   : Timer1 Library
 * Author    : Prajin Palangsantikul
 * Company   : AppSoftTech Co.,Ltd.
 * WWW       : www.appsofttech.com
 * Date      : 09/07/08
 * Ref.      :  
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <timer.h>          // Timer module library functions 


//----------------------------------------------------:Data types
typedef unsigned char byte;


//----------------------------------------------------:Global Variable
struct TIME_T1 {
  byte sec;     // secound
  byte min;     // minute
  byte hr;      // hour
}time_t1;

byte tick=0;
byte dsp=1;     // for LCD display


//----------------------------------------------------:Timer1 Interrupt
void _ISR _T1Interrupt(void)
{
  char i;
  
  if ( ++tick == 2 ) {    // 2 tick for second
    if ( time_t1.sec++ == 59 ) {
      time_t1.sec = 0;
      if ( time_t1.min++ == 59 ) {
        time_t1.min = 0;
        if (time_t1.hr++ == 23 ) {
          time_t1.hr = 0;
        }
      }
    }
    dsp=1;
    tick = 0;   // Clear Tick
  }
  _T1IF = 0;    // Clear Timer1 Interrupt flag
}

//----------------------------------------------------:Timer Set
void Timer_Set(byte hr, byte min, byte sec)
{
  time_t1.sec = sec;
  time_t1.min = min;
  time_t1.hr = hr;
}

//----------------------------------------------------:Timer1 Init
void Timer1_Init(void)
{
  unsigned int config, period;

  CloseTimer1();					      // Close Timer1

  ConfigIntTimer1(T1_INT_ON);		// Config Int Timer1

  // Timer1 Control Register (T1CON) Bit Defines
  config = T1_ON & 				      // Timer1 ON	
           T1_IDLE_STOP & 		  // stop operation during sleep
           T1_GATE_OFF & 		    // Timer Gate time accumulation disabled
           T1_PS_1_64 & 		    // Prescaler 1:64
           T1_SYNC_EXT_OFF &    // Do not synch external clk input
           T1_SOURCE_INT;			  // Internal clock source
              
  period = 57604;					      // Set PR1 Register		

  OpenTimer1(config,period);	  // Open Timer1
}
