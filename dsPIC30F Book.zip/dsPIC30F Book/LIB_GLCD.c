/*
Author    : prajin palangsantikul                     
Company   : appsofttech co.,ltd.                      
Filename  :	LIB_GLCD.C
Purpose   : Graphics LCD 128x64 Module (GLCD 128x64)
Ref..     :	
Date      :	15/10/2005                                
*/

//----------------------------------------------------:LCD PIN
// GLCD Pin connections:
// 1   : VSS     to GND
// 2   : VDD     to +5V
// 3   : V0      to VR  (Constrast adjustment)
// 4   : RS      to RB0
// 5   : R/W     to RB1
// 6   : E       to RB2
// 7-14: DB0-DB7 to ** User Define
// 15  : CS1     to RB3
// 16  : CS2     to RB4
// 17  : RST     to RB5
// 18  : VEE     to 20k Ohm POT
// 19  : A       to +5V (Positive voltage for LED backlight)
// 20  : K       to GND (Negavtive voltage for LED backlight)


//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC


//----------------------------------------------------:Define
#define   Set_Bit(p, b) 	  (p) |= (1 << (b))
#define   Clear_Bit(p, b)	  (p) &= ~(1 << (b))


#define GLCD_WIDTH        128

#ifdef GLCD_DATA_MAKE8_BIT

#define GLCD_DATA_TRIS1   TRISE    // Data Bus 0 to 5
#define GLCD_DATA_LAT1    LATE
#define GLCD_DATA_PORT1   PORTE
#define GLCD_DATA_TRIS2   TRISD     // Data Bus 6 to 7
#define GLCD_DATA_LAT2    LATD
#define GLCD_DATA_PORT2   PORTD

#else

#define GLCD_DATA_TRIS    TRISC    // Data Bus 0 to 7
#define GLCD_DATA_LAT     LATC
#define GLCD_DATA_PORT    PORTC

#endif

#define GLCD_CTRL_TRIS    TRISB     // Control Bus
#define GLCD_CTRL_LAT     LATB      // 
#define GLCD_CTRL_RS      _LATB0    // Data or Instruction input
#define GLCD_CTRL_RW      _LATB1    // Read/Write
#define GLCD_CTRL_E       _LATB2    // Enable
#define GLCD_CTRL_CS1     _LATB3    // Chip Selection 1
#define GLCD_CTRL_CS2     _LATB4    // Chip Selection 2
#define GLCD_CTRL_RST     _LATB5    // Reset

#define GLCD_LEFT         0
#define GLCD_RIGHT        1
#define ON                1
#define OFF               0


//----------------------------------------------------:Function Prototypes
static void delay_cycles(char cy);
static void GLCD_WriteByte(char side, char data);
static char GLCD_ReadByte(char side);

void GLCDPixel(char x, char y, char color);
void GLCDFillScreen(char color);
void GLCDInit(char mode);


//----------------------------------------------------:Delay cycle
static void delay_cycles(char cy) 
{
  for(;cy>0;cy--) {
    Nop(); 
    Nop();    // Add for XT PLL16
    Nop();    // "-------------"
  }    
}  

//----------------------------------------------------:Initialize the LCD.
void GLCDInit(char mode)
{
  GLCD_CTRL_TRIS = 0;              // Set port output

  // Initialze some pins
  GLCD_CTRL_RST = 1;
  GLCD_CTRL_E   = 0;
  GLCD_CTRL_CS1 = 0;
  GLCD_CTRL_CS2 = 0;

  GLCD_CTRL_RS  = 0;              // Set for instruction
  GLCD_WriteByte(GLCD_LEFT,  0xC0);    // Specify first RAM line at the top
  GLCD_WriteByte(GLCD_RIGHT, 0xC0);    // of the screen
  GLCD_WriteByte(GLCD_LEFT,  0x40);    // Set the column address to 0
  GLCD_WriteByte(GLCD_RIGHT, 0x40);
  GLCD_WriteByte(GLCD_LEFT,  0xB8);    // Set the page address to 0
  GLCD_WriteByte(GLCD_RIGHT, 0xB8);

  if(mode == ON) {
     GLCD_WriteByte(GLCD_LEFT,  0x3F); // Turn the display on
     GLCD_WriteByte(GLCD_RIGHT, 0x3F);
  } else {
     GLCD_WriteByte(GLCD_LEFT,  0x3E); // Turn the display off
     GLCD_WriteByte(GLCD_RIGHT, 0x3E);
  }

  GLCDFillScreen(OFF);                // Clear the display
}

//----------------------------------------------------:GLCD Pixel
// Turn a pixel on a graphic LCD on or off
void GLCDPixel(char x, char y, char color)
{
  char data;
  char side = GLCD_LEFT;      // Stores which chip to use on the LCD

  if(x > 63) {                // Check for first or second display area
     x -= 64;
     side = GLCD_RIGHT;
  }

  GLCD_CTRL_RS = 0;           // Set for instruction
  Clear_Bit(x,7);              // Clear the MSB. Part of an instruction code
  Set_Bit(x,6);                // Set bit 6. Also part of an instruction code
  GLCD_WriteByte(side, x);    // Set the horizontal address
  GLCD_WriteByte(side, ((y/8) & 0xBF) | 0xB8);  // Set the vertical page address
  GLCD_CTRL_RS = 1;           // Set for data
  GLCD_ReadByte(side);        // Need two reads to get data
  
  data = GLCD_ReadByte(side); //  at new address

  if(color == ON)
     Set_Bit(data, y%8);      // Turn the pixel on
  else                        // or
     Clear_Bit(data, y%8);    // turn the pixel off

  GLCD_CTRL_RS = 0;           // Set for instruction
  GLCD_WriteByte(side, x);    // Set the horizontal address
  GLCD_CTRL_RS = 1;           // Set for data
  GLCD_WriteByte(side, data); // Write the pixel data
}

/*** Fill the LCD screen with the passed in color */
void GLCDFillScreen(char color)
{
  char i, j;

  // Loop through the vertical pages
  for(i = 0; i < 8; ++i) {
    GLCD_CTRL_RS = 0;                         // Set for instruction
    GLCD_WriteByte(GLCD_LEFT, 0x40);          // Set horizontal address to 0
    GLCD_WriteByte(GLCD_RIGHT, 0x40);
    GLCD_WriteByte(GLCD_LEFT, i | 0xB8);      // Set page address
    GLCD_WriteByte(GLCD_RIGHT, i | 0xB8);
    GLCD_CTRL_RS = 1;          // Set for data

    // Loop through the horizontal sections
    for(j = 0; j < 64; ++j) {
      GLCD_WriteByte(GLCD_LEFT, 0xFF*color);  // Turn pixels on or off
      GLCD_WriteByte(GLCD_RIGHT, 0xFF*color); // Turn pixels on or off
     }
  }
}

//----------------------------------------------------:GLCD WriteByte
// Write a byte of data to the specified chip
void GLCD_WriteByte(char side, char data)
{  
#ifdef GLCD_DATA_MAKE8_BIT
  GLCD_DATA_TRIS1 = 0;    // Set port to output
  GLCD_DATA_TRIS2 = 0;
#else
  GLCD_DATA_TRIS = 0;     // Set port to output  
#endif

  delay_cycles(20);       //*** wait GLCD ready
      
  if(side)                // Choose which side to write to
    GLCD_CTRL_CS2 = 1;
  else
    GLCD_CTRL_CS1 = 1;

  GLCD_CTRL_RW = 0;       // Set for writing  
#ifdef GLCD_DATA_MAKE8_BIT
  GLCD_DATA_LAT1 = data;      // Put the data on the port
  GLCD_DATA_LAT2 = (data>>6); // Bit at 6,7 only
#else
  GLCD_DATA_LAT = data;       // Put the data on the port
#endif

  delay_cycles(1);

  GLCD_CTRL_E = 1;        // Pulse the enable pin
  delay_cycles(5);	
  GLCD_CTRL_E = 0;

  GLCD_CTRL_CS1 = 0;      // Reset the chip select lines
  GLCD_CTRL_CS2 = 0;
}

//----------------------------------------------------:GLCD ReadByte
// Reads a byte of data from the specified chip
char GLCD_ReadByte(char side)
{
  char data;                // Stores the data read from the LCD

#ifdef GLCD_DATA_MAKE8_BIT
  GLCD_DATA_TRIS1 = 0xFF;    // Set port to input
  GLCD_DATA_TRIS2 = 0xFF;
#else
  GLCD_DATA_TRIS = 0xFF;    // Set port to input
#endif  
  delay_cycles(20);         //*** wait GLCD ready

  GLCD_CTRL_RW = 1;         // Set for reading

  if(side)                  // Choose which side to write to
    GLCD_CTRL_CS2 = 1;
  else
    GLCD_CTRL_CS1 = 1;

  delay_cycles(1);
  GLCD_CTRL_E = 1;          // Pulse the enable pin
  delay_cycles(4);
#ifdef GLCD_DATA_MAKE8_BIT
  data = GLCD_DATA_PORT2;    // Get the data from the display's output register
  data = data << 6;          // Shift bit to high bit at 6,7 
  data = data | GLCD_DATA_PORT1;  // Mark bit
#else  
  data = GLCD_DATA_PORT;    // Get the data from the display's output register
#endif  
  GLCD_CTRL_E = 0;

  GLCD_CTRL_CS1 = 0;        // Reset the chip select lines
  GLCD_CTRL_CS2 = 0;
  
  return data;              // Return the read data
}
