/*
Author    : prajin palangsantikul                     
Company   : appsofttech co.,ltd.                      
Filename  :	LIB_GLCD51105110.c
Purpose   : NOKIA LCD 5110 Library
Ref..     :	
Date      :	09/12/2008
*/

//----------------------------------------------------:Includes
#define _SPI_V1     // SPI V1
#include "spi.h"    // Header for SPI module library functions

//----------------------------------------------------:PIN dsPIC30F2010
// SDI1/RF2,  SDO1/RF3,   SCK1/RE8,   SS1/RB2

//----------------------------------------------------:Define PIN GLCD5110
#define GLCD_SDIN   _LATF3      // D/C  (Data)
#define GLCD_SCK    _LATE8      // SCLK (Clock)
#define GLCD_LED    _LATE0      // LED+ (Back Light)
#define GLCD_DC     _LATE1      // D/C  (Data/Command)
#define GLCD_RESET  _LATE2      // RESET
#define GLCD_SCE    _LATE3      // SCE  (Chip Enable)

#define GLCD5110_X_RES	84
#define GLCD5110_Y_RES	48

#define GLCD5110_SIZE	  540     // ((GLCD5110_X_RES * GLCD5110_Y_RES) / 8.0)

#include "font5x7.h"

typedef unsigned char UINT8_T;
typedef unsigned int  UINT16_T;

//----------------------------------------------------:Prototype Functions
void SPI_MasterInit(void);

void GLCD5110_GotoXY(UINT8_T x, UINT8_T y);
void GLCD5110_Write(UINT8_T cData);
void GLCD5110_PutChar(UINT8_T ch);
void GLCD5110_PutStr(UINT8_T *str);

void GLCD5110_Reset(void);
void GLCD5110_Clear(void);
void GLCD5110_Init(void);

// GLCD Enable/Disable
#define GLCD5110_ENABLE     (GLCD_SCE = 0)
#define GLCD5110_DISABLE    (GLCD_SCE = 1)
// GLCD Data/Command
#define GLCD5110_DATA       (GLCD_DC = 1)
#define GLCD5110_COMMAND    (GLCD_DC = 0)
// GLCD Back Light On/Off
#define GLCD5110_BK_ON      (GLCD_LED = 1)
#define GLCD5110_BK_OFF     (GLCD_LED = 0)


//----------------------------------------------------:Wait_Nop
// Count down Nop
void Wait_Nop(UINT16_T c)
{
  for(;c>0;c--) 
    Nop();
}          

//----------------------------------------------------:GLCD5110_Write
// GLCD5110 Write
void GLCD5110_Write(UINT8_T cData)
{       
  // Start transmission
  putcSPI1(cData);
  // Wait for transmission complete
  while (SPI1STATbits.SPITBF); 
}

//----------------------------------------------------:GLCD5110_GotoXY
// Goto X,Y 
void GLCD5110_GotoXY(UINT8_T x, UINT8_T y)
{
  GLCD5110_COMMAND;

  GLCD5110_Write(0x80|x);	// X-Address = 0
  GLCD5110_Write(0x40|y);	// Y-Address = 0
  Wait_Nop(5000);
}

//----------------------------------------------------:GLCD5110_PutChar
// Put character
void GLCD5110_PutChar(UINT8_T ch)
{
  UINT16_T p;
	
  if ((ch<0x20)||(ch>0x7F))
    return;

  p = (ch-32)*5;			// Position ASCII 
  
  for (ch=0;ch<5;ch++) {	
    GLCD5110_Write(Font5x7[p++]);
  }
}

//----------------------------------------------------:GLCD5110_PutStr
// Put String
void GLCD5110_PutStr(UINT8_T *str)
{
  GLCD5110_DATA;

  while (*str) {
    GLCD5110_PutChar(*str++);
  }  
  GLCD5110_Write(0x00); // Spacebar character
}

//----------------------------------------------------:GLCD5110_Reset
void GLCD5110_Reset(void)
{
  GLCD_RESET = 1;     // GLCD5110 Reset
  Nop();
  GLCD_RESET = 0;     
  Nop();
  GLCD_RESET = 1;
}

//----------------------------------------------------:GLCD5110_Clear
// Clear Screen
void GLCD5110_Clear(void)
{
  UINT16_T i;
  
  GLCD5110_DATA;

  for (i=0;i<GLCD5110_SIZE;i++) {
    GLCD5110_Write(0x00);
  }
}

//----------------------------------------------------:GLCD5110_Init
// Initialize GLCD5110
void GLCD5110_Init(void)
{    
  SPI_MasterInit();       // Initialize SPI    

  GLCD5110_BK_OFF;        // GLCD Back Light OFF
  GLCD5110_Reset();       // GLCD5110 Reset

  GLCD5110_ENABLE;
  
  GLCD5110_Clear();

  GLCD5110_COMMAND;       // Initial LCD Command
  GLCD5110_Write(0x21);
  GLCD5110_Write(0xC8);   
  GLCD5110_Write(0x06);
  GLCD5110_Write(0x13);
  GLCD5110_Write(0x20);
  GLCD5110_Write(0x0C);
}

//----------------------------------------------------:SPI1 ISR
void _ISR _SPI1Interrupt(void)
{
  _SPI1IF = 0;      // clear SPI 1 interrupt flag
}

//----------------------------------------------------:SPI_MasterInit
void SPI_MasterInit(void)
{	
  _TRISE0 = 0;    // Set RE0, RE1, RE2, RE3 output port
  _TRISE1 = 0;
  _TRISE2 = 0;
  _TRISE3 = 0;
  
  _TRISE8 = 0;    // Set RE8 output port
  _TRISF3 = 0;    // Set RF3 output port

  CloseSPI1();    // CloseSPI. Disables SPI module

  // OpenSPI 
  OpenSPI1( // SPIxCON reg.	
            FRAME_ENABLE_OFF &    // Frame SPI support Disable 
            FRAME_SYNC_OUTPUT &   // Frame sync pulse Output (master)
            ENABLE_SDO_PIN &      // SDO pin is used by module
            SPI_MODE16_OFF &		  // Communication is byte wide (use 8 bit data mode) 
            SPI_SMP_OFF &         // Input data sampled at middle of data output time
            SPI_CKE_ON &          // Transmit happens from active clock 
                                  // state to idle clock state
            SLAVE_ENABLE_OFF &		// Slave Select not used by module            
            CLK_POL_ACTIVE_HIGH & // (CKP) Idle state for clock is low, active is high
            MASTER_ENABLE_ON &		// Master Mode
            SEC_PRESCAL_8_1 &			// Secondary Prescale 8:1
            PRI_PRESCAL_64_1,			// Primary Prescale 64:1            
            // SPIxSTAT Reg.
            SPI_ENABLE &          // Enable SPI module
            SPI_IDLE_CON &        // SPI working on Idle mode
            SPI_RX_OVFLOW_CLR     // Automatic clear receive overflow flag
            );

  DisableIntSPI1;                 // Macros to Disable interrupts of SPI1  
}

