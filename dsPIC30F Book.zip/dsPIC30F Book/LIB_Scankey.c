/*
Author    : prajin palangsantikul                     
Company   : appsofttech co.,ltd.                      
Filename  :	LIB_Scankey.c 
Purpose   : Scan keypad
Ref..     :	-
Date      :	17/06/2008                                
*/

//----------------------------------------------------:NOTE
// Key switch matrix (Row x Col)
// Row
// R1 -> RB0  	, R2 -> RB1
// R3 -> RB2  	, R4 -> RB3
// Column
// C1 -> RD0	  , C2 -> RD1
// C3 -> RF2


//----------------------------------------------------:Includes
#include <p30fxxxx.h>           // generic header file for dsPIC


//----------------------------------------------------:Defines
// Key pad
#define KEY_TRIS_OUT_C1   _TRISD0   // LATC scan key pad
#define KEY_TRIS_OUT_C2   _TRISD1
#define KEY_TRIS_OUT_C3   _TRISF2
#define KEY_OUT_C1        _LATD0
#define KEY_OUT_C2        _LATD1
#define KEY_OUT_C3        _LATF2
#define KEY_TRIS_IN       TRISB     // PORTB read key pad
#define KEY_IN            PORTB

unsigned char kbd_pad[4][3] ={{'7','8','9'},
  			                      {'4','5','6'},
	  		                      {'1','2','3'},
				                      {'*','0','#'},
                             };


//----------------------------------------------------:Function Prototypes
unsigned char KBDGet(void);


//----------------------------------------------------:KBD Wait
static void KBD_Wait(unsigned int dly)
{
  for (; dly>0; dly--)
    Nop();
}          

//----------------------------------------------------:KBD Get
unsigned char KBDGet(void)
{
  static char last_key;
  unsigned char col, row;

  KEY_TRIS_IN = 0x0F;   // Set port for scankey
      
  for (col=0; col<3; col++) {    
    if (col == 0) { KEY_OUT_C1 = 0; KEY_OUT_C2 = KEY_OUT_C3 = 1; }
    if (col == 1) { KEY_OUT_C2 = 0; KEY_OUT_C1 = KEY_OUT_C3 = 1; }
    if (col == 2) { KEY_OUT_C3 = 0; KEY_OUT_C1 = KEY_OUT_C2 = 1; }
    
    row = (KEY_IN & 0x0F);      // read row                
    
    switch (row) {
      case 0x0E: row = 3; break;
      case 0x0D: row = 2; break;
      case 0x0B: row = 1; break;
      case 0x07: row = 0; break;
      default:   row = 4;
    }
        
    if (row != 4) {
      if (kbd_pad[row][col] == last_key)  
        return ('\0');
        
      last_key = kbd_pad[row][col];
      return (last_key);
    }
    KBD_Wait(10);       // delay kbd
  }
  
  last_key = '\0';
  return (last_key);  
}
