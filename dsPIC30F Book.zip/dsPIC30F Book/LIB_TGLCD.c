/*
Author    : prajin palangsantikul                     
Company   : appsofttech co.,ltd.                      
Filename  :	LIB_TGLCD.C
Purpose   : Thai Graphics LCD 128x64 Module (TGLCD 128x64)
Ref..     :	-
Date      :	15/10/2005                                
*/

//----------------------------------------------------:Includes
#include <p30fxxxx.h>       // generic header file for dsPIC
#include <ctype.h>          // for tolower, toascii function
#include <string.h>         // for strlen function


//----------------------------------------------------:Define
#define SP_FONT  7    // Space font


//----------------------------------------------------:Function Prototypes
static void TGLCD_Putbitmap(char x, char y, unsigned char ascii);
void TGLCDThaixy(char column, char row, unsigned char *content);


//----------------------------------------------------:Put bitmap
static void TGLCD_Putbitmap(char x, char y, unsigned char ascii)
{
	unsigned char bitmap[8] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };
  register char x1, y1;
  unsigned char ch;

	for( y1=0; y1<16; y1++)
  {
    ch = (unsigned char) font[ascii][y1];
		for(x1=0; x1<8; x1++) 
    {      
			if( (ch & bitmap[x1] ) != 0)
        GLCDPixel((x+x1), (y+y1), 1);        
    }
  }
}

//----------------------------------------------------:Thai X,Y
void TGLCDThaixy(char column, char row, unsigned char *content)
{
	char k ,ypix, xpix;
	unsigned char asc;
  static unsigned char tmp_asc;

//	column=(column-1)*8;
//	row=(row-1)*16;

	for(k=0; k<strlen(content); k++)
	{
		ypix=0; xpix=0;
		if(tolower(content[k]) > 160) asc = tolower(content[k]);
		else asc = toascii(content[k]);
		if(asc==209) { xpix = -6; }
		if((asc>215) & (asc<219)) { xpix = -SP_FONT; }
		if((asc>211) & (asc<216)) { xpix = -SP_FONT; }
		if((asc>230) & (asc<239)) { 
      if(tmp_asc==209) { 
        ypix = -3;
        xpix = -SP_FONT;
      } else if(tmp_asc==211) {
        ypix = -3;
        xpix = -6;        
      } else if((tmp_asc>211) & (tmp_asc<216)) {
        ypix = -3;
        xpix = -6;
      } else {
        ypix = +1;
  		  xpix = -SP_FONT;
      }       
    }

		TGLCD_Putbitmap(column+xpix, row+ypix, asc);

		if(asc<209) column +=SP_FONT;
		if((asc>209) & (asc<212)) column +=SP_FONT;
		if((asc>223) & (asc<231)) column +=SP_FONT;
		if((asc>239) & (asc<250)) column +=SP_FONT;		
		tmp_asc = asc;		
	}
}
