/*
Author		:	prajin palangsantikul
Company		:	appsofttech co.,ltd.
Filename	:	LIB_Uart1.c
Purpose		:	UART1 Utility
Date		  :	12/07/2008
*/

//----------------------------------------------------:NOTE
// USART PIN (dsPIC30F2010)
// Normal pins 
// U1RTX -> RF2, U1TX -> RF3
// ALT pins
// U1ATX -> RC13, U1ARX -> RC14

//----------------------------------------------------:Includes
#include <uart.h>			// uart module


//----------------------------------------------------:Calc Baud Rate Generator
#define Fcy             7372800.0                 // Fosc 7.3728MHz
#define BAUD_RATE       9600.0                    // Baud Rate 9600 bps
#define BAUD_RATE_GEN   (Fcy/(16.0*BAUD_RATE))-1  // Baud Rate Generator 


//----------------------------------------------------:TX_ISR
/***** use in Program main *****
void _ISR _U1TXInterrupt(void) { _U1TXIF = 0; }
*/
//----------------------------------------------------:RX_ISR
/***** use in Program main *****
void _ISR _U1RXInterrupt(void) { _U1RXIF = 0; }
*/

//----------------------------------------------------:Uart1PrintChar
// print character to uart1
void Uart1PrintChar(unsigned int dat)
{
    putcUART1(dat);
    while (BusyUART1());        // wait for transmission to complete
}

//----------------------------------------------------:Uart1PrintStr
// Print string to uart1
void Uart1PrintStr(unsigned char *str_uart)
{
    putsUART1((unsigned int *)str_uart);
    while (BusyUART1());        // wait for transmission to complete
}

//----------------------------------------------------:Uart1Init
// Initialize UART1
// Function : Uart1Init(ISR_ON)
// Input    : char ISR_ON = 0 -> Disable Interrupt
//                          1 -> Enable Interrupt
//
void Uart1Init(char ISR_ON)
{
  unsigned int U1MODEvalue, U1STAvalue, BaudRate;	

  CloseUART1();			// Close UART1

  if (ISR_ON) {
    // Config Interrupt UART1
    ConfigIntUART1(UART_RX_INT_EN &       // Receive interrupt enabled
                   UART_RX_INT_PR6 &      // Priority RX interrupt 6
                   UART_TX_INT_EN &       // transmit interrupt enabled
                   UART_TX_INT_PR2 );     // Priority TX interrupt 2
  }
  
  U1MODEvalue = UART_EN &                 // Module enable
                UART_IDLE_CON &           // Work in IDLE mode
				//UART_RX_TX &              // Communication through the normal pins
				//UART_ALTRX_ALTTX &        // Communication through ALT pins                
                UART_DIS_WAKE &           // Disable Wake-up on START bit Detect during SLEEP Mode bit
                UART_DIS_LOOPBACK &       // Loop back disabled
                UART_DIS_ABAUD &          // Input to Capture module from ICx pin
                UART_NO_PAR_8BIT &        // no parity 8 bit		
                UART_1STOPBIT;            // 1 stop bit

  U1STAvalue	= UART_INT_TX_BUF_EMPTY &   // Interrupt on TXBUF becoming empty
                UART_TX_PIN_NORMAL &      // UART TX pin operates normally
                UART_INT_RX_CHAR &        // Interrupt on every char received
                UART_ADR_DETECT_DIS &     // address detect disable	
                UART_RX_OVERRUN_CLEAR;    // Rx buffer Over run status bit clear		

  BaudRate = BAUD_RATE_GEN;		            // BaudRate 9600 pbs
  
  // Open UART1
  OpenUART1(U1MODEvalue, U1STAvalue, BaudRate);
  
//  U1MODEbits.ALTIO = 0;                   // Communication through ALT pins
}

//----------------------------------------------------:Main
/*int main(void)
{
	char str_uart[] = "\n\rUart Test\n\r";

	Init_Uart1();			// Initialize the UART1
	putsUART1((unsigned int *)str_uart);

	while(1)
	;
	return 0;
}
*/




