#include <avr/io.h>             // AVR device-specific IO definitions
#include <compat/deprecated.h>

#define F_CPU 8000000UL         // XTAL 8 MHz
#include <util/delay.h>         // header file implement simple delay loops

#define SW(x,y)     (x&(1<<y))


/*** delay miliseconds function */
void delay_ms(uint16_t i)
{
  for (; i>0; i--)
    _delay_ms(1);
}

/*** Main function */
int main(void)
{
  int pos = 1;
  
  cbi(DDRA,0);
  cbi(DDRA,1);
  sbi(DDRA,2);
  sbi(DDRA,3);

  sbi(PORTA,0);
  sbi(PORTA,1);

  while(1) 
  {
    if (SW(PINA,0) == 0) 
      pos = 1;    // Forward Travel
    else if (SW(PINA,1) == 0) 
      pos = 0;    // Reverse Travel

    if (pos) {
      cbi(PORTA,2); sbi(PORTA,3); delay_ms(5);
      cbi(PORTA,2); cbi(PORTA,3); delay_ms(5);
      sbi(PORTA,2); cbi(PORTA,3); delay_ms(5);
      sbi(PORTA,2); sbi(PORTA,3); delay_ms(5);
    } else {
      sbi(PORTA,2); sbi(PORTA,3); delay_ms(5);
      sbi(PORTA,2); cbi(PORTA,3); delay_ms(5);
      cbi(PORTA,2); cbi(PORTA,3); delay_ms(5);
      cbi(PORTA,2); sbi(PORTA,3); delay_ms(5);
    }
  }

    return 0;
} 
